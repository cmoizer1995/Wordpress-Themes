# G. CMUK Inspired Elementor Theme v19 Accordion


## G revision visible theme name

This package has:
- ZIP alphabet: g.
- Theme folder: g-cmuk-inspired-elementor-theme-v19-accordion
- WordPress theme name: G. CMUK Inspired Elementor Theme v19 Accordion

So it is visible in Appearance → Themes as the official new G accordion version.


## H revision - front-end accordion render fix

This fixes the issue where the accordion did not appear on the front end.

Changes:
- Forces WordPress menus to output submenu depth up to 4 using wp_nav_menu_args
- Adds accordion arrows only when a real `.sub-menu` exists on the front end
- Targets common menu classes/IDs, not just one theme-specific class
- Icon opens and closes the submenu
- No dash is added before child items
- Theme name visible in WordPress as H. CMUK Inspired Elementor Theme v19 Accordion Render Fix


## I revision - true accordion open/close

Fixes the previous behaviour where child items appeared but did not behave like a real accordion.

Changes:
- all submenus are forced closed on page/menu open
- arrow click opens the submenu
- clicking the same arrow again closes it
- opening one submenu closes sibling submenus
- no dash/prefix is added before child items
- theme name visible as I. CMUK Inspired Elementor Theme v19 True Accordion


## J revision - CMUK rename and Customizer controls

Based on locked I.I true accordion code.

Slot-in changes only:
- Renamed internal theme identity from GOV.UK/GOVUK to CMUK
- Theme folder: j-cmuk-inspired-elementor-theme-v19-true-accordion
- WordPress theme name: J. CMUK Inspired Elementor Theme v19 True Accordion
- Keeps the working true accordion/menu code
- Adds Customizer controls:
  - Header background colour
  - Header text colour
  - Footer text
  - Footer background colour
  - Footer text colour
  - Footer alignment
- Adds shortcode: [cmuk_footer_text]

No core layout/menu rebuild has been done.


## K revision - Search removed, menu sizing normalised, footer height restored

Based on J, preserving the locked I.I true accordion behaviour.

Slot-in changes only:
- removes search output from the theme
- disables theme/core search form rendering
- hides search inputs/forms if any remain from old markup
- makes all menu items the same height whether they are accordion parents or normal links
- makes child menu items align/size consistently
- restores footer to a compact height like before footer options were added


## L revision - Header search removed and submenu alignment fixed

Based on K, preserving the locked I.I true accordion behaviour.

Slot-in changes only:
- removes the search icon/button from the header
- disables remaining header search markup/output if WordPress tries to render it
- aligns submenu child links with parent menu links on the same left edge
- removes child menu pseudo prefixes/dashes
- keeps the accordion open/close behaviour unchanged

## M revision - Same menu on all devices

Based on locked L.

Slot-in only:
- uses the same working mobile accordion menu on tablet and desktop
- disables old desktop flyout/hover menu behaviour
- scales header/menu for mobile, tablet/iPad, and laptop/desktop
- preserves no-search header, submenu alignment, compact footer, and true accordion behaviour

## N revision - Desktop menu with mobile accordion behaviour

Based on M.

Slot-in only:
- desktop/laptop gets a proper horizontal desktop menu layout
- dropdowns still use the same click-to-open/click-to-close accordion behaviour from mobile
- hover/focus flyout behaviour is disabled so the arrow controls the dropdown
- grandchild dropdowns open to the right on desktop
- mobile/tablet stacked accordion remains unchanged

## O revision - Desktop accordion styled like mobile

Based on N.

Slot-in only:
- desktop menu aligns to the right/end
- desktop dropdown/accordion panels use the same blue background and white text as mobile
- desktop submenu rows use mobile-style separators and sizing
- accordion behaviour remains the same working click open/close system from N

## P revision - Desktop accordion stacks like mobile

Based on O.

Slot-in only:
- keeps desktop top-level menu aligned right
- dropdowns keep the mobile blue/white accordion styling
- grandchildren/deeper levels stack underneath the parent item instead of flying sideways
- arrow icons flip down/up like mobile
- accordion open/close behaviour remains unchanged

## Q revision - Exact mobile accordion controls on desktop

Based on P.

Slot-in only:
- desktop now uses the exact same icon control behaviour as mobile
- icon click opens
- same icon click closes
- icon points down when closed
- icon points up when open
- hover/focus no longer controls the dropdown
- P desktop stacked layout is preserved

## R revision - Tablet accordion stays on screen

Based on Q.

Slot-in only:
- keeps exact mobile accordion controls from Q
- fixes tablet/iPad dropdown overflow
- forces tablet submenu panels to stack inside the viewport
- prevents horizontal screen overflow
- keeps desktop and mobile behaviour otherwise unchanged

## S revision - Dropdowns stay inside the screen

Based on R.

Slot-in only:
- fixes iPad/tablet landscape overflow
- top-level dropdown panels pull inward from the right edge
- child/grandchild panels stack inside the parent panel
- long links wrap instead of exceeding the screen
- preserves Q/R accordion controls and CMUK styling

## T revision - Header menu alignment and spacing

Based on S.

Slot-in only:
- aligns desktop/tablet menu to the left with safe screen padding
- aligns site title to the right with safe screen padding
- removes oversized gaps between menu links
- makes top-level menu buttons equal size whether they have submenu accordions or not
- keeps working accordion behaviour and contained dropdowns from S


## U revision - requested desktop/tablet positioning

Based on T.

- site title moved to the left position from screenshot one
- menu moved to the right position from screenshot two
- preserved equal menu spacing
- preserved working accordion behaviour
- preserved dropdown containment

## X revision
Mobile/tablet opened menu rows now use 16px text to match the Menu button while keeping the site title large and accordion behaviour working.

## AD revision - remove hover and active menu states

Based on AC.

This removes visual hover, focus, active, current-menu and pseudo-element styling from the menu so it always looks exactly like the normal, non-hover state.

## AF revision - Site title and menu alignment controls

Based on AE.

Slot-in only:
- adds separate Customizer control for Site title alignment
- adds separate Customizer control for Menu bar alignment
- both use footer-style alignment logic
- desktop keeps a 10px inset from the left and right screen edges
- default: site title left, menu right
- accordion/menu behaviour preserved

## AG revision - Elementor-style alignment controls

Based on AF.

This replaces the footer-style alignment attempt with a proper Elementor-style alignment system:
- Site title alignment: Left / Center / Right
- Menu alignment: Left / Center / Right
- desktop only
- 10px edge padding is preserved
- uses flex-start / center / flex-end like Elementor controls

## AH revision - Stretch header like Elementor

Based on AG.

Slot-in only:
- forces the desktop header to stretch full viewport width like Elementor Stretch Section
- keeps 10px left/right safe edge padding
- keeps separate Site title and Menu alignment controls
- preserves accordion/menu behaviour

## AJ revision - Full header stretch and permanent mobile dividers

Based on AI.

Slot-in only:
- header/title/menu row stretches across the full blue bar
- site title now uses the same flex behaviour as the menu side
- mobile/tablet keeps permanent thin dividers
- hover/active/focus menu states are neutralised on mobile
- accordion behaviour preserved

## AK revision - Parent dividers match submenu dividers

Based on AJ.

Slot-in only:
- applies the exact same thin accordion submenu divider style to all mobile parent/top-level menu rows
- parent links, submenu links and grandchild rows now share the same divider style
- hover/current/active states stay neutral
- accordion behaviour preserved

## AL revision
Fixes site title alignment persistence with dedicated CMUK Header Alignment controls and late priority CSS.

## AM revision - Elementor Stretch Section header

Based on AL.

Slot-in only:
- forces the blue header background to full viewport width like Elementor Stretch Section
- inner title/menu row also spans the full header width
- keeps 10px safe left/right edge padding
- preserves AL Customizer alignment controls
- preserves accordion/menu behaviour

## AN revision - Elementor JSON header coded into theme

Based on AM and `cmukheader.json`.

This does **not** import Elementor JSON on every page load.

The JSON layout has been converted into coded theme structure:
- stretched full-width section
- full-width layout
- blue background `#1D70B8`
- two-column header row
- left column: WordPress site title
- right column: existing CMUK WordPress menu
- keeps the existing CMUK accordion menu engine
- keeps submenu depth up to 4
- keeps permanent mobile divider behaviour

## AO revision - Site title edge alignment fix

Based on AN.

Slot-in only:
- site title now aligns using the same edge logic as the menu side
- site title sits flush-left with only the 10px safe edge inset
- standardises title text to 16px
- keeps menu text at 16px
- preserves stretched Elementor-style blue header
- preserves CMUK accordion menu engine

## AP revision - Mobile menu toggle fix

Based on AO.

Slot-in only:
- fixes mobile menu open/close behaviour
- adds proper spacing between the menu icon and “Menu” text
- rotates icon when menu is open
- preserves stretched Elementor-style header
- preserves CMUK accordion menu engine

## AQ revision - Header text 16px and no mobile dividers

Based on AP.

Slot-in only:
- forces all text inside the blue header bar to 16px
- removes every mobile/tablet menu divider
- removes mobile hover/active/focus divider effects
- removes the divider between site title and Menu button
- preserves mobile menu open behaviour and accordion engine

## AV revision - Site title size front-end fix

Based on AU.

Fixes the Customizer Site Title Font Size setting so the saved value is applied directly on the live front end with high-priority CSS.

## AW revision - hard coded 20px site title

Based on AV.

Uses the exact same high-priority front-end selector logic from AV, but permanently hard codes the blue header site title to 20px.

## AX revision - remove header/font settings

Based on AW.

Removed:
- Site Title Font Size setting
- CMUK Header Alignment section
- Site title alignment setting
- Menu alignment setting

Hard coded:
- blue header site title remains 20px
- footer text alignment permanently centered

## AY revision - mobile menu alignment only

Based on uploaded working AX.

Change:
- mobile menu links now align left like the site title
- accordion icons stay on the right
- no other AX behaviour removed or changed

## AZ revision - mobile accordion icon alignment

Based on AY.

Change:
- mobile menu text stays aligned left like the site title
- accordion/dropdown icons are forced permanently to the far right end of each menu row
- supports both pseudo-element arrows and real toggle/icon elements


## BA revision - dynamic footer branding

Based on AZ.

Changes:
- footer now automatically uses the WordPress Site Title
- footer displays: © YEAR Site Title | Made with love by Connor Moizer
- Connor Moizer links to https://connormoizer.com
- footer colours still use existing footer background/text colour settings
