
document.addEventListener('DOMContentLoaded', function(){

  const menuSelectors = [
    '.cmuk-menu',
    '.cmuk-menu',
    '.menu',
    '#primary-menu',
    '#cmuk-primary-menu',
    'nav ul'
  ];

  const menus = Array.from(document.querySelectorAll(menuSelectors.join(',')))
    .filter((menu, index, self) => self.indexOf(menu) === index);

  menus.forEach(function(menu){

    menu.querySelectorAll('li').forEach(function(item){

      const submenu = item.querySelector(':scope > .sub-menu');
      const link = item.querySelector(':scope > a');

      if(!submenu || !link) return;

      item.classList.add('cmuk-has-submenu');
      link.setAttribute('aria-haspopup', 'true');
      link.setAttribute('aria-expanded', 'false');

      let toggle = link.querySelector(':scope > .cmuk-submenu-toggle');

      if(!toggle){
        toggle = document.createElement('span');
        toggle.className = 'cmuk-submenu-toggle';
        toggle.setAttribute('role', 'button');
        toggle.setAttribute('tabindex', '0');
        toggle.setAttribute('aria-label', 'Toggle submenu');
        toggle.setAttribute('aria-hidden', 'false');
        link.appendChild(toggle);
      }

      function toggleSubmenu(event){
        event.preventDefault();
        event.stopPropagation();

        const isOpen = item.classList.contains('cmuk-submenu-open');

        if(isOpen){
          item.classList.remove('cmuk-submenu-open');
          link.setAttribute('aria-expanded', 'false');
        }else{
          item.classList.add('cmuk-submenu-open');
          link.setAttribute('aria-expanded', 'true');
        }
      }

      toggle.addEventListener('click', toggleSubmenu);

      toggle.addEventListener('keydown', function(event){
        if(event.key === 'Enter' || event.key === ' '){
          toggleSubmenu(event);
        }
      });

    });

  });

});
