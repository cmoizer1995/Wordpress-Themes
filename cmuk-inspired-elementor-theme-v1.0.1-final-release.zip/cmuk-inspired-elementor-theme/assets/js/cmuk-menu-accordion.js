
document.addEventListener('DOMContentLoaded', function(){

  document.querySelectorAll('.menu-item-has-children, .page_item_has_children').forEach(function(item){

    const link = item.querySelector(':scope > a');
    const submenu = item.querySelector(':scope > .sub-menu');

    if(!link || !submenu) return;

    item.classList.add('cmuk-has-submenu');

    let toggle = link.querySelector('.cmuk-submenu-toggle');

    if(!toggle){
      toggle = document.createElement('span');
      toggle.className = 'cmuk-submenu-toggle';
      toggle.setAttribute('role','button');
      toggle.setAttribute('tabindex','0');
      link.appendChild(toggle);
    }

    function toggleMenu(e){
      e.preventDefault();
      e.stopPropagation();

      item.classList.toggle('cmuk-submenu-open');
    }

    toggle.addEventListener('click', toggleMenu);

    toggle.addEventListener('keydown', function(e){
      if(e.key === 'Enter' || e.key === ' '){
        toggleMenu(e);
      }
    });
  });

});
