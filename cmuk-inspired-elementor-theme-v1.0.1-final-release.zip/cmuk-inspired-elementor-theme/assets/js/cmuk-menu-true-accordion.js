
document.addEventListener('DOMContentLoaded', function(){

  function closeItem(item){
    item.classList.remove('cmuk-submenu-open');

    const link = item.querySelector(':scope > a');
    const toggle = link ? link.querySelector(':scope > .cmuk-submenu-toggle') : null;

    if(link) link.setAttribute('aria-expanded', 'false');
    if(toggle) toggle.setAttribute('aria-label', 'Open submenu');
  }

  function openItem(item){
    item.classList.add('cmuk-submenu-open');

    const link = item.querySelector(':scope > a');
    const toggle = link ? link.querySelector(':scope > .cmuk-submenu-toggle') : null;

    if(link) link.setAttribute('aria-expanded', 'true');
    if(toggle) toggle.setAttribute('aria-label', 'Close submenu');
  }

  function closeSiblings(item){
    const parentList = item.parentElement;
    if(!parentList) return;

    parentList.querySelectorAll(':scope > li.cmuk-submenu-open').forEach(function(openItem){
      if(openItem !== item){
        closeItem(openItem);
      }
    });
  }

  function setupMenu(menu){
    menu.querySelectorAll('li').forEach(function(item){
      const submenu = item.querySelector(':scope > .sub-menu');
      const link = item.querySelector(':scope > a');

      if(!submenu || !link) return;

      item.classList.add('cmuk-has-submenu', 'menu-item-has-children');
      link.setAttribute('aria-haspopup', 'true');

      let toggle = link.querySelector(':scope > .cmuk-submenu-toggle');

      if(!toggle){
        toggle = document.createElement('span');
        toggle.className = 'cmuk-submenu-toggle';
        toggle.setAttribute('role', 'button');
        toggle.setAttribute('tabindex', '0');
        toggle.setAttribute('aria-label', 'Open submenu');
        link.appendChild(toggle);
      }

      closeItem(item);

      function mobileAccordionToggle(event){
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        const isOpen = item.classList.contains('cmuk-submenu-open');

        if(isOpen){
          closeItem(item);
        }else{
          closeSiblings(item);
          openItem(item);
        }
      }

      // EXACT mobile control: icon is the control, on every screen size.
      toggle.addEventListener('click', mobileAccordionToggle, true);

      toggle.addEventListener('keydown', function(event){
        if(event.key === 'Enter' || event.key === ' '){
          mobileAccordionToggle(event);
        }
      }, true);
    });
  }

  const menus = Array.from(document.querySelectorAll('.cmuk-menu, .menu, #primary-menu, #cmuk-primary-menu, nav ul'))
    .filter((menu, index, self) => self.indexOf(menu) === index);

  menus.forEach(setupMenu);

  // When the main menu opens, reset all accordions closed exactly like mobile.
  document.querySelectorAll('.cmuk-menu-toggle, .cmuk-gov-header__toggle, [aria-controls]').forEach(function(mainToggle){
    mainToggle.addEventListener('click', function(){
      setTimeout(function(){
        document.querySelectorAll('li.cmuk-submenu-open').forEach(closeItem);
      }, 0);
    });
  });

  // Desktop safety: click outside closes open menus.
  document.addEventListener('click', function(event){
    if(!event.target.closest('nav')){
      document.querySelectorAll('li.cmuk-submenu-open').forEach(closeItem);
    }
  });

});
