document.addEventListener('DOMContentLoaded', function () {
  var menuButton = document.querySelector('.cmuk-header__menu-button');
  var menu = document.getElementById('cmuk-primary-menu');
  var searchButton = document.querySelector('.cmuk-header__search-button');
  var search = document.getElementById('cmuk-header-search');

  if (menuButton && menu) {
    menuButton.addEventListener('click', function () {
      var expanded = menuButton.getAttribute('aria-expanded') === 'true';
      menuButton.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      menu.classList.toggle('is-open', !expanded);
      if (searchButton && search && !expanded) {
        searchButton.setAttribute('aria-expanded', 'false');
        search.classList.remove('is-open');
      }
    });
  }

  if (searchButton && search) {
    searchButton.addEventListener('click', function () {
      var expanded = searchButton.getAttribute('aria-expanded') === 'true';
      searchButton.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      search.classList.toggle('is-open', !expanded);
      if (menuButton && menu && !expanded) {
        menuButton.setAttribute('aria-expanded', 'false');
        menu.classList.remove('is-open');
      }
      if (!expanded) {
        var input = search.querySelector('input');
        if (input) input.focus();
      }
    });
  }
});


document.addEventListener('DOMContentLoaded', function () {
  var serviceToggle = document.querySelector('.cmuk-service-navigation__toggle');
  var serviceList = document.getElementById('cmuk-service-navigation-list');

  if (serviceToggle && serviceList) {
    serviceToggle.addEventListener('click', function () {
      var expanded = serviceToggle.getAttribute('aria-expanded') === 'true';
      serviceToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      serviceList.classList.toggle('is-open', !expanded);
    });
  }
});
