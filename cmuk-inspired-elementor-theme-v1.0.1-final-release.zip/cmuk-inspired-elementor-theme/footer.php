<?php
/**
 * CMUK Footer
 */
?>

<footer id="colophon" class="site-footer cmuk-footer">
    <div class="cmuk-footer-inner">
        <p class="cmuk-footer-text">
            © <?php echo esc_html( date('Y') ); ?>
            <?php bloginfo('name'); ?>
            <span class="cmuk-footer-divider"> | </span>
            Made with love by
            <a href="https://connormoizer.com" target="_blank" rel="noopener">
                Connor Moizer
            </a>
        </p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
