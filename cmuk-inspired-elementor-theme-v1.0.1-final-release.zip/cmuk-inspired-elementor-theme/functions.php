<?php
if (!defined('ABSPATH')) { exit; }

function cmuk_inspired_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('custom-logo', array('height'=>80,'width'=>260,'flex-height'=>true,'flex-width'=>true));
    add_theme_support('menus');
    register_nav_menus(array(
        'primary' => __('Primary menu', 'cmuk-inspired-elementor-theme')
    ));
}
add_action('after_setup_theme', 'cmuk_inspired_setup');

function cmuk_inspired_assets() {
    wp_enqueue_style('cmuk-inspired-style', get_stylesheet_uri(), array(), '19.0');
    wp_enqueue_script('cmuk-inspired-header', get_template_directory_uri() . '/assets/js/header.js', array(), '19.0', true);
}
add_action('wp_enqueue_scripts', 'cmuk_inspired_assets');

function cmuk_inspired_customize_register($wp_customize) {
    $wp_customize->add_section('cmuk_header_options', array(
        'title' => __('CMUK Header Options', 'cmuk-inspired-elementor-theme'),
        'priority' => 30
    ));

    $wp_customize->add_setting('cmuk_header_colour', array(
        'default' => 'blue',
        'sanitize_callback' => function($value) {
            return in_array($value, array('blue','black'), true) ? $value : 'blue';
        }
    ));

    $wp_customize->add_control('cmuk_header_colour', array(
        'label' => __('Header colour', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'select',
        'choices' => array(
            'blue' => __('Blue current CMUK-style header', 'cmuk-inspired-elementor-theme'),
            'black' => __('Black classic CMUK-style header', 'cmuk-inspired-elementor-theme')
        )
    ));

    $wp_customize->add_setting('cmuk_show_search', array(
        'default' => true,
        'sanitize_callback' => function($value) { return (bool) $value; }
    ));

    $wp_customize->add_control('cmuk_show_search', array(
        'label' => __('Show mobile search icon', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'checkbox'
    ));

    $wp_customize->add_setting('cmuk_enable_mobile_menu', array(
        'default' => true,
        'sanitize_callback' => function($value) { return (bool) $value; }
    ));

    $wp_customize->add_control('cmuk_enable_mobile_menu', array(
        'label' => __('Enable header menu', 'cmuk-inspired-elementor-theme'),
        'description' => __('Turn this off to hide all header menu/navigation on desktop and mobile.', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'checkbox'
    ));

    $wp_customize->add_setting('cmuk_service_name', array(
        'default' => get_bloginfo('name'),
        'sanitize_callback' => 'sanitize_text_field'
    ));

    $wp_customize->add_control('cmuk_service_name', array(
        'label' => __('Service navigation name', 'cmuk-inspired-elementor-theme'),
        'description' => __('Shown in the CMUK-style service navigation bar.', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'text'
    ));

    $wp_customize->add_setting('cmuk_show_service_box', array(
        'default' => true,
        'sanitize_callback' => function($value) { return (bool) $value; }
    ));

    $wp_customize->add_control('cmuk_show_service_box', array(
        'label' => __('Show service box globally', 'cmuk-inspired-elementor-theme'),
        'description' => __('Turn this off to hide the CPT/service title box across the site.', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'checkbox'
    ));

    $wp_customize->add_setting('cmuk_menu_button_text', array(
        'default' => 'Menu',
        'sanitize_callback' => 'sanitize_text_field'
    ));

    $wp_customize->add_control('cmuk_menu_button_text', array(
        'label' => __('Mobile menu button text', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'text'
    ));

    $wp_customize->add_setting('cmuk_header_hover_opacity', array(
        'default' => 0,
        'sanitize_callback' => function($value) {
            $value = floatval($value);
            if ($value < 0) { $value = 0; }
            if ($value > 1) { $value = 1; }
            return $value;
        }
    ));

    $wp_customize->add_control('cmuk_header_hover_opacity', array(
        'label' => __('Header hover transparency / opacity', 'cmuk-inspired-elementor-theme'),
        'description' => __('Set to 0 for fully transparent hover. Increase only if you want a visible hover shade.', 'cmuk-inspired-elementor-theme'),
        'section' => 'cmuk_header_options',
        'type' => 'range',
        'input_attrs' => array(
            'min' => 0,
            'max' => 1,
            'step' => 0.01
        )
    ));
}
add_action('customize_register', 'cmuk_inspired_customize_register');

function cmuk_inspired_body_classes($classes) {
    $classes[] = get_theme_mod('cmuk_header_colour', 'blue') === 'black' ? 'cmuk-header-black' : 'cmuk-header-blue';

    if (!get_theme_mod('cmuk_enable_mobile_menu', true)) {
        $classes[] = 'cmuk-mobile-menu-disabled';
        $classes[] = 'cmuk-menu-disabled';
    }

    if (!get_theme_mod('cmuk_show_service_box', true)) {
        $classes[] = 'cmuk-service-box-disabled';
    }

    return $classes;
}
add_filter('body_class', 'cmuk_inspired_body_classes');

function cmuk_header_style_shortcode($atts) {
    $atts = shortcode_atts(array('colour' => get_theme_mod('cmuk_header_colour', 'blue')), $atts);
    $colour = $atts['colour'] === 'black' ? 'black' : 'blue';
    return '<style>body .cmuk-header, body .cmuk-header__nav, body .cmuk-header__search{background:' . ($colour === 'black' ? '#0b0c0c' : '#1d70b8') . ';border-bottom:0!important;} body .cmuk-header a, body .cmuk-header button{text-decoration:none!important;}</style>';
}
add_shortcode('cmuk_header_style', 'cmuk_header_style_shortcode');


function cmuk_inspired_header_hover_inline_css() {
    $opacity = floatval(get_theme_mod('cmuk_header_hover_opacity', 0));
    if ($opacity < 0) { $opacity = 0; }
    if ($opacity > 1) { $opacity = 1; }
    ?>
    <style id="cmuk-inspired-header-hover-override">
      body .cmuk-header,
      body .cmuk-header * {
        --cm-header-hover-opacity: <?php echo esc_html($opacity); ?> !important;
      }

      body .cmuk-header a:hover,
      body .cmuk-header a:focus,
      body .cmuk-header a:active,
      body .cmuk-header button:hover,
      body .cmuk-header button:focus,
      body .cmuk-header button:active,
      body .cmuk-header .menu-item:hover,
      body .cmuk-header .menu-item:focus,
      body .cmuk-header .menu-item:active,
      body .cmuk-header .menu-item a:hover,
      body .cmuk-header .menu-item a:focus,
      body .cmuk-header .menu-item a:active,
      body .cmuk-header__logo:hover,
      body .cmuk-header__logo:focus,
      body .cmuk-header__logo:active,
      body .cmuk-header__nav a:hover,
      body .cmuk-header__nav a:focus,
      body .cmuk-header__nav a:active,
      body .cmuk-header__menu-button:hover,
      body .cmuk-header__menu-button:focus,
      body .cmuk-header__menu-button:active,
      body .cmuk-header__search-button:hover,
      body .cmuk-header__search-button:focus,
      body .cmuk-header__search-button:active {
        background: <?php echo $opacity <= 0 ? (get_theme_mod('cmuk_header_colour', 'blue') === 'black' ? '#0b0c0c' : '#1d70b8') : 'rgba(255,255,255,' . esc_html($opacity) . ')'; ?> !important;
        background-color: <?php echo $opacity <= 0 ? (get_theme_mod('cmuk_header_colour', 'blue') === 'black' ? '#0b0c0c' : '#1d70b8') : 'rgba(255,255,255,' . esc_html($opacity) . ')'; ?> !important;
        background-image: none !important;
        color: #ffffff !important;
        text-decoration: none !important;
        box-shadow: none !important;
        outline: none !important;
      }
    </style>
    <?php
}
add_action('wp_head', 'cmuk_inspired_header_hover_inline_css', 999);



class CMUK_Service_Navigation_Walker extends Walker_Nav_Menu {
    public function start_lvl(&$output, $depth = 0, $args = null) {}

    public function end_lvl(&$output, $depth = 0, $args = null) {}

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $is_current = in_array('current-menu-item', $classes, true) || in_array('current_page_item', $classes, true);
        $item_classes = 'cmuk-service-navigation__item' . ($is_current ? ' cmuk-service-navigation__item--active' : '');

        $atts = array();
        $atts['href'] = !empty($item->url) ? $item->url : '#';
        $atts['class'] = 'cmuk-service-navigation__link';
        if ($is_current) {
            $atts['aria-current'] = 'true';
        }

        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $attributes .= ' ' . $attr . '="' . esc_attr($value) . '"';
            }
        }

        $title = apply_filters('the_title', $item->title, $item->ID);
        if ($is_current) {
            $title = '<strong class="cmuk-service-navigation__active-fallback">' . esc_html($title) . '</strong>';
        } else {
            $title = esc_html($title);
        }

        $output .= '<li class="' . esc_attr($item_classes) . '">';
        $output .= '<a' . $attributes . '>' . $title . '</a>';
    }

    public function end_el(&$output, $item, $depth = 0, $args = null) {
        $output .= '</li>';
    }
}



function cmuk_inspired_get_service_title() {
    $fallback = get_theme_mod('cmuk_service_name', get_bloginfo('name'));

    if (is_post_type_archive()) {
        $post_type = get_query_var('post_type');
        if (is_array($post_type)) {
            $post_type = reset($post_type);
        }
        $obj = get_post_type_object($post_type);
        if ($obj && !empty($obj->labels->name)) {
            return $obj->labels->name;
        }
    }

    if (is_singular()) {
        $post_type = get_post_type();
        $obj = get_post_type_object($post_type);

        if ($obj && !in_array($post_type, array('page', 'post', 'attachment'), true)) {
            if (!empty($obj->labels->singular_name)) {
                return $obj->labels->singular_name;
            }

            if (!empty($obj->labels->name)) {
                return $obj->labels->name;
            }
        }
    }

    if (is_home() || is_single()) {
        $obj = get_post_type_object('post');
        if ($obj && !empty($obj->labels->name)) {
            return $obj->labels->name;
        }
    }

    return $fallback;
}



function cmuk_service_box_toggle_shortcode($atts) {
    $atts = shortcode_atts(array(
        'show' => 'yes',
        'editor_note' => 'yes',
    ), $atts);

    $show = strtolower($atts['show']) !== 'no' && strtolower($atts['show']) !== 'off' && strtolower($atts['show']) !== 'false';

    if ($show) {
        return '';
    }

    $output = '<style id="cmuk-service-box-elementor-toggle">body .cmuk-service-navigation--reference{display:none!important;}</style>';

    if (is_user_logged_in() && $atts['editor_note'] === 'yes') {
        $output .= '<div class="cmuk-service-box-toggle-note">Service box hidden on this page by Elementor toggle.</div>';
    }

    return $output;
}
add_shortcode('cmuk_service_box_toggle', 'cmuk_service_box_toggle_shortcode');

function cmuk_inspired_register_elementor_service_box_widget($widgets_manager) {
    if (!class_exists('\Elementor\Widget_Base')) {
        return;
    }

    if (!class_exists('CMUK_Elementor_Service_Box_Toggle_Widget')) {
        class CMUK_Elementor_Service_Box_Toggle_Widget extends \Elementor\Widget_Base {
            public function get_name() {
                return 'cmuk_service_box_toggle';
            }

            public function get_title() {
                return __('CMUK Service Box Toggle', 'cmuk-inspired-elementor-theme');
            }

            public function get_icon() {
                return 'eicon-toggle';
            }

            public function get_categories() {
                return array('general');
            }

            protected function register_controls() {
                $this->start_controls_section('section_content', array(
                    'label' => __('Service Box', 'cmuk-inspired-elementor-theme'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ));

                $this->add_control('show_service_box', array(
                    'label' => __('Show service box on this page', 'cmuk-inspired-elementor-theme'),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __('Show', 'cmuk-inspired-elementor-theme'),
                    'label_off' => __('Hide', 'cmuk-inspired-elementor-theme'),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ));

                $this->add_control('show_editor_note', array(
                    'label' => __('Show editor note when hidden', 'cmuk-inspired-elementor-theme'),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __('Yes', 'cmuk-inspired-elementor-theme'),
                    'label_off' => __('No', 'cmuk-inspired-elementor-theme'),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ));

                $this->end_controls_section();
            }

            protected function render() {
                $settings = $this->get_settings_for_display();

                if (($settings['show_service_box'] ?? 'yes') === 'yes') {
                    if (is_user_logged_in() && \Elementor\Plugin::$instance->editor->is_edit_mode()) {
                        echo '<div class="cmuk-service-box-toggle-note">Service box is enabled on this page.</div>';
                    }
                    return;
                }

                echo '<style id="cmuk-service-box-elementor-widget-toggle">body .cmuk-service-navigation--reference{display:none!important;}</style>';

                if (($settings['show_editor_note'] ?? 'yes') === 'yes' && is_user_logged_in()) {
                    echo '<div class="cmuk-service-box-toggle-note">Service box hidden on this page by Elementor toggle.</div>';
                }
            }
        }
    }

    $widgets_manager->register(new \CMUK_Elementor_Service_Box_Toggle_Widget());
}

function cmuk_inspired_elementor_service_box_widget_init() {
    if (did_action('elementor/loaded')) {
        add_action('elementor/widgets/register', 'cmuk_inspired_register_elementor_service_box_widget');
    }
}
add_action('plugins_loaded', 'cmuk_inspired_elementor_service_box_widget_init');



function cmuk_inspired_get_public_post_type_choices() {
    $types = get_post_types(array('public' => true), 'objects');
    $choices = array();

    foreach ($types as $type => $object) {
        if ($type === 'attachment') {
            continue;
        }

        $choices[$type] = !empty($object->labels->name) ? $object->labels->name : $type;
    }

    return $choices;
}

function cmuk_inspired_sanitize_post_type_list($value) {
    if (is_string($value)) {
        $value = array_filter(array_map('trim', explode(',', $value)));
    }

    if (!is_array($value)) {
        return array();
    }

    $allowed = array_keys(cmuk_inspired_get_public_post_type_choices());
    return array_values(array_intersect($value, $allowed));
}

if (class_exists('WP_Customize_Control') && !class_exists('CMUK_Post_Type_Checkbox_Control')) {
    class CMUK_Post_Type_Checkbox_Control extends WP_Customize_Control {
        public $type = 'cmuk_post_type_checkboxes';

        public function render_content() {
            if (empty($this->choices)) {
                echo '<span class="customize-control-title">' . esc_html($this->label) . '</span>';
                echo '<p>' . esc_html__('No public post types found.', 'cmuk-inspired-elementor-theme') . '</p>';
                return;
            }

            $value = $this->value();
            if (is_string($value)) {
                $value = array_filter(array_map('trim', explode(',', $value)));
            }
            if (!is_array($value)) {
                $value = array();
            }
            ?>
            <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
            <?php if (!empty($this->description)) : ?>
                <span class="description customize-control-description"><?php echo esc_html($this->description); ?></span>
            <?php endif; ?>

            <input type="hidden" <?php $this->link(); ?> value="<?php echo esc_attr(implode(',', $value)); ?>" />

            <div class="cmuk-cpt-checkboxes">
                <?php foreach ($this->choices as $post_type => $label) : ?>
                    <label style="display:block;margin:6px 0;">
                        <input type="checkbox" value="<?php echo esc_attr($post_type); ?>" <?php checked(in_array($post_type, $value, true)); ?>>
                        <?php echo esc_html($label); ?> <code><?php echo esc_html($post_type); ?></code>
                    </label>
                <?php endforeach; ?>
            </div>

            <script>
            (function(){
                const container = document.currentScript.previousElementSibling;
                const hidden = container.previousElementSibling;
                if (!container || !hidden) return;
                container.addEventListener('change', function(){
                    const checked = Array.from(container.querySelectorAll('input[type="checkbox"]:checked')).map(function(input){
                        return input.value;
                    });
                    hidden.value = checked.join(',');
                    hidden.dispatchEvent(new Event('change'));
                });
            })();
            </script>
            <?php
        }
    }
}

function cmuk_inspired_service_box_allowed_for_current_content() {
    if (!get_theme_mod('cmuk_show_service_box', true)) {
        return false;
    }

    $enabled = get_theme_mod('cmuk_service_box_post_types', array('page', 'post'));
    if (is_string($enabled)) {
        $enabled = array_filter(array_map('trim', explode(',', $enabled)));
    }
    if (!is_array($enabled)) {
        $enabled = array();
    }

    if (empty($enabled)) {
        return false;
    }

    if (is_post_type_archive()) {
        $post_type = get_query_var('post_type');
        if (is_array($post_type)) {
            $post_type = reset($post_type);
        }
        return in_array($post_type, $enabled, true);
    }

    if (is_singular()) {
        return in_array(get_post_type(), $enabled, true);
    }

    if (is_home()) {
        return in_array('post', $enabled, true);
    }

    if (is_page()) {
        return in_array('page', $enabled, true);
    }

    return get_theme_mod('cmuk_service_box_show_other', false);
}



function cmuk_menu_accordion_assets() {
    wp_enqueue_script(
        'cmuk-menu-accordion',
        get_template_directory_uri() . '/assets/js/cmuk-menu-accordion.js',
        array(),
        '19.0.1',
        true
    );
}
add_action('wp_enqueue_scripts', 'cmuk_menu_accordion_assets', 30);


function h_cmuk_accordion_render_assets() {
    wp_enqueue_script(
        'h-cmuk-accordion-render',
        get_template_directory_uri() . '/assets/js/cmuk-menu-accordion-render.js',
        array(),
        '19.0.2',
        true
    );
}
add_action('wp_enqueue_scripts', 'h_cmuk_accordion_render_assets', 30);

function h_cmuk_force_primary_menu_depth($args) {
    if (is_array($args)) {
        if (empty($args['depth']) || intval($args['depth']) < 2) {
            $args['depth'] = 4;
        }
        if (empty($args['fallback_cb'])) {
            $args['fallback_cb'] = false;
        }
    }
    return $args;
}
add_filter('wp_nav_menu_args', 'h_cmuk_force_primary_menu_depth', 20);


function i_cmuk_true_accordion_assets() {
    wp_enqueue_script(
        'i-cmuk-true-accordion',
        get_template_directory_uri() . '/assets/js/cmuk-menu-true-accordion.js',
        array(),
        '19.0.3',
        true
    );
}
add_action('wp_enqueue_scripts', 'i_cmuk_true_accordion_assets', 99);

function i_cmuk_force_menu_depth($args) {
    if (is_array($args)) {
        $args['depth'] = 4;
        if (empty($args['fallback_cb'])) {
            $args['fallback_cb'] = false;
        }
    }
    return $args;
}
add_filter('wp_nav_menu_args', 'i_cmuk_force_menu_depth', 99);


/**
 * J revision: CMUK Customizer controls.
 * Slot-in only: does not rebuild header/menu/accordion logic.
 */
function j_cmuk_sanitize_alignment($value) {
    return in_array($value, array('left', 'center', 'right'), true) ? $value : 'left';
}

function j_cmuk_customize_register($wp_customize) {
    $wp_customize->add_section('j_cmuk_theme_settings', array(
        'title' => __('CMUK Theme Settings', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'priority' => 30,
    ));

    $wp_customize->add_setting('j_cmuk_header_colour', array(
        'default' => '#1d70b8',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'j_cmuk_header_colour', array(
        'label' => __('Header background colour', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => 'j_cmuk_theme_settings',
        'settings' => 'j_cmuk_header_colour',
    )));

    $wp_customize->add_setting('j_cmuk_header_text_colour', array(
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'j_cmuk_header_text_colour', array(
        'label' => __('Header text colour', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => 'j_cmuk_theme_settings',
        'settings' => 'j_cmuk_header_text_colour',
    )));

    $wp_customize->add_setting('j_cmuk_footer_text', array(
        'default' => '© ' . date('Y') . ' Connor Moizer',
        'sanitize_callback' => 'wp_kses_post',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control('j_cmuk_footer_text', array(
        'label' => __('Footer text', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => 'j_cmuk_theme_settings',
        'type' => 'textarea',
    ));

    $wp_customize->add_setting('j_cmuk_footer_background', array(
        'default' => '#f3f2f1',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'j_cmuk_footer_background', array(
        'label' => __('Footer background colour', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => 'j_cmuk_theme_settings',
        'settings' => 'j_cmuk_footer_background',
    )));

    $wp_customize->add_setting('j_cmuk_footer_text_colour', array(
        'default' => '#0b0c0c',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'j_cmuk_footer_text_colour', array(
        'label' => __('Footer text colour', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => 'j_cmuk_theme_settings',
        'settings' => 'j_cmuk_footer_text_colour',
    )));

    $wp_customize->add_setting('j_cmuk_footer_alignment', array(
        'default' => 'left',
        'sanitize_callback' => 'j_cmuk_sanitize_alignment',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control('j_cmuk_footer_alignment', array(
        'label' => __('', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => 'j_cmuk_theme_settings',
        'type' => 'select',
        'choices' => array(
            'left' => __('Left', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'center' => __('Center', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'right' => __('Right', 'j-cmuk-inspired-elementor-theme-v19-true-accordion'),
        ),
    ));
}
add_action('customize_register', 'j_cmuk_customize_register');

function j_cmuk_customizer_css_variables() {
    $header_colour = get_theme_mod('j_cmuk_header_colour', '#1d70b8');
    $header_text_colour = get_theme_mod('j_cmuk_header_text_colour', '#ffffff');
    $footer_background = get_theme_mod('j_cmuk_footer_background', '#f3f2f1');
    $footer_text_colour = get_theme_mod('j_cmuk_footer_text_colour', '#0b0c0c');
    $footer_alignment = get_theme_mod('j_cmuk_footer_alignment', 'left');

    $css = ':root{'
        . '--cmuk-header-colour:' . esc_attr($header_colour) . ';'
        . '--cmuk-header-text-colour:' . esc_attr($header_text_colour) . ';'
        . '--cmuk-footer-background:' . esc_attr($footer_background) . ';'
        . '--cmuk-footer-text-colour:' . esc_attr($footer_text_colour) . ';'
        . '--cmuk-footer-alignment:' . esc_attr($footer_alignment) . ';'
        . '}'
        . '.cmuk-site-footer,.site-footer,footer.cmuk-site-footer{text-align:' . esc_attr($footer_alignment) . ';}';

    wp_register_style('j-cmuk-customizer-inline', false, array(), '19.0.4');
    wp_enqueue_style('j-cmuk-customizer-inline');
    wp_add_inline_style('j-cmuk-customizer-inline', $css);
}
add_action('wp_enqueue_scripts', 'j_cmuk_customizer_css_variables', 99);

function j_cmuk_footer_text_shortcode() {
    return wp_kses_post(get_theme_mod('j_cmuk_footer_text', '© ' . date('Y') . ' Connor Moizer'));
}
add_shortcode('cmuk_footer_text', 'j_cmuk_footer_text_shortcode');


/**
 * K revision: disable theme search output without touching the working accordion/menu core.
 */
function k_cmuk_disable_search_output($form) {
    return '';
}
add_filter('get_search_form', 'k_cmuk_disable_search_output', 99);

function k_cmuk_remove_search_widget() {
    unregister_widget('WP_Widget_Search');
}
add_action('widgets_init', 'k_cmuk_remove_search_widget', 99);

/**
 * K revision: Customizer inline fixes for equal menu height and compact footer.
 */
function k_cmuk_slotin_css_fixes() {
    $css = '
      .search-form,.wp-block-search,.site-search,.header-search,.cmuk-search,input[type="search"]{display:none!important;}
      .cmuk-has-submenu>a,.menu-item-has-children>a,.page_item_has_children>a,.cmuk-menu li>a,.menu li>a,nav ul li>a{min-height:56px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;padding-top:14px!important;padding-bottom:14px!important;line-height:1.25!important;}
      .sub-menu li>a{min-height:56px!important;padding-top:14px!important;padding-bottom:14px!important;}
      .cmuk-site-footer,.site-footer,footer.cmuk-site-footer{padding-top:16px!important;padding-bottom:16px!important;min-height:0!important;line-height:1.5!important;font-size:16px!important;}
      .cmuk-footer-inner,.site-footer .cmuk-footer-inner,footer .cmuk-footer-inner{padding-top:0!important;padding-bottom:0!important;min-height:0!important;}
    ';
    wp_register_style('k-cmuk-slotin-fixes', false, array(), '19.0.5');
    wp_enqueue_style('k-cmuk-slotin-fixes');
    wp_add_inline_style('k-cmuk-slotin-fixes', $css);
}
add_action('wp_enqueue_scripts', 'k_cmuk_slotin_css_fixes', 100);


/**
 * L revision: remove header search icon/button and align submenu links.
 * Slot-in only; true accordion logic is preserved.
 */
function l_cmuk_disable_search_output($form) {
    return '';
}
add_filter('get_search_form', 'l_cmuk_disable_search_output', 100);

function l_cmuk_remove_header_search_align_submenus() {
    $css = '
      header .search-form,header .wp-block-search,header .site-search,header .header-search,header .cmuk-search,header .search-toggle,header .search-submit,header .dashicons-search,header [class*="search"]{display:none!important;visibility:hidden!important;width:0!important;min-width:0!important;max-width:0!important;height:0!important;padding:0!important;margin:0!important;overflow:hidden!important;border:0!important;}
      .cmuk-menu .sub-menu,.menu .sub-menu,nav .sub-menu{padding-left:0!important;margin-left:0!important;text-indent:0!important;}
      .cmuk-menu>li>a,.cmuk-menu .sub-menu li>a,.menu>li>a,.menu .sub-menu li>a,nav ul>li>a,nav ul .sub-menu li>a{padding-left:0!important;margin-left:0!important;text-indent:0!important;box-sizing:border-box!important;}
      .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,nav ul .sub-menu li>a{display:flex!important;align-items:center!important;justify-content:space-between!important;width:100%!important;}
      .cmuk-menu .sub-menu a:before,.menu .sub-menu a:before,nav .sub-menu a:before{content:""!important;display:none!important;}
      .cmuk-submenu-toggle{margin-left:auto!important;}
    ';
    wp_register_style('l-cmuk-header-menu-fix', false, array(), '19.0.6');
    wp_enqueue_style('l-cmuk-header-menu-fix');
    wp_add_inline_style('l-cmuk-header-menu-fix', $css);
}
add_action('wp_enqueue_scripts', 'l_cmuk_remove_header_search_align_submenus', 101);


function m_cmuk_same_menu_all_devices() {
    $css = '.cmuk-menu,.menu,nav ul{display:block!important;width:100%!important;}
    .cmuk-menu>li,.menu>li,nav ul>li{display:block!important;width:100%!important;float:none!important;position:relative!important;border-bottom:1px solid rgba(255,255,255,.3)!important;}
    .cmuk-menu li>a,.menu li>a,nav ul li>a{display:flex!important;align-items:center!important;justify-content:space-between!important;width:100%!important;box-sizing:border-box!important;text-align:left!important;}
    .cmuk-menu .sub-menu,.menu .sub-menu,nav .sub-menu{position:static!important;left:auto!important;top:auto!important;min-width:0!important;width:100%!important;border:0!important;box-shadow:none!important;background:transparent!important;padding-left:0!important;margin-left:0!important;display:none!important;}
    .cmuk-submenu-open>.sub-menu{display:block!important;}
    @media(min-width:768px) and (max-width:1024px){.cmuk-site-title,.cmuk-gov-header__brand,header .site-title{font-size:38px!important;}.cmuk-menu li>a,.menu li>a,nav ul li>a{min-height:60px!important;font-size:22px!important;padding-top:16px!important;padding-bottom:16px!important;}.cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,.cmuk-primary-navigation,.cmuk-gov-nav,header nav{max-width:960px!important;margin-left:auto!important;margin-right:auto!important;}}
    @media(min-width:1025px){.cmuk-site-title,.cmuk-gov-header__brand,header .site-title{font-size:40px!important;}.cmuk-menu li>a,.menu li>a,nav ul li>a{min-height:62px!important;font-size:23px!important;padding-top:17px!important;padding-bottom:17px!important;}.cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,.cmuk-primary-navigation,.cmuk-gov-nav,header nav{max-width:1100px!important;margin-left:auto!important;margin-right:auto!important;}}
    @media(min-width:769px){.cmuk-menu li:hover>.sub-menu,.menu li:hover>.sub-menu,nav li:hover>.sub-menu,.cmuk-menu li:focus-within>.sub-menu,.menu li:focus-within>.sub-menu,nav li:focus-within>.sub-menu{display:none!important;}.cmuk-menu li.cmuk-submenu-open>.sub-menu,.menu li.cmuk-submenu-open>.sub-menu,nav li.cmuk-submenu-open>.sub-menu{display:block!important;}}';
    wp_register_style('m-cmuk-same-menu-all-devices', false, array(), '19.0.7');
    wp_enqueue_style('m-cmuk-same-menu-all-devices');
    wp_add_inline_style('m-cmuk-same-menu-all-devices', $css);
}
add_action('wp_enqueue_scripts', 'm_cmuk_same_menu_all_devices', 120);


function n_cmuk_desktop_menu_mobile_accordion() {
    $css = '
    @media(min-width:1025px){
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{display:block!important;max-width:1100px!important;margin-left:auto!important;margin-right:auto!important;}
      .cmuk-menu,.menu,nav ul{display:flex!important;align-items:stretch!important;justify-content:flex-start!important;width:auto!important;gap:0!important;}
      .cmuk-menu>li,.menu>li,nav ul>li{display:block!important;width:auto!important;float:none!important;position:relative!important;border-bottom:0!important;}
      .cmuk-menu>li>a,.menu>li>a,nav ul>li>a{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:10px!important;width:auto!important;min-height:56px!important;padding:18px 16px!important;font-size:16px!important;line-height:1.25!important;text-align:left!important;box-sizing:border-box!important;}
      .cmuk-menu .sub-menu,.menu .sub-menu,nav .sub-menu{display:none!important;position:absolute!important;top:100%!important;left:0!important;min-width:230px!important;width:max-content!important;max-width:360px!important;background:#ffffff!important;border:2px solid #0b0c0c!important;box-shadow:none!important;padding:0!important;margin:0!important;z-index:99999!important;}
      .cmuk-menu li:hover>.sub-menu,.menu li:hover>.sub-menu,nav li:hover>.sub-menu,.cmuk-menu li:focus-within>.sub-menu,.menu li:focus-within>.sub-menu,nav li:focus-within>.sub-menu{display:none!important;}
      .cmuk-menu li.cmuk-submenu-open>.sub-menu,.menu li.cmuk-submenu-open>.sub-menu,nav li.cmuk-submenu-open>.sub-menu{display:block!important;}
      .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,nav .sub-menu li>a{display:flex!important;align-items:center!important;justify-content:space-between!important;width:100%!important;min-height:44px!important;padding:12px 14px!important;font-size:16px!important;font-weight:400!important;line-height:1.3!important;white-space:nowrap!important;text-align:left!important;color:#0b0c0c!important;background:#ffffff!important;text-decoration:none!important;}
      .cmuk-menu .sub-menu li>a:hover,.menu .sub-menu li>a:hover,nav .sub-menu li>a:hover,.cmuk-menu .sub-menu li>a:focus,.menu .sub-menu li>a:focus,nav .sub-menu li>a:focus{background:#ffdd00!important;color:#0b0c0c!important;text-decoration:none!important;}
      .cmuk-menu .sub-menu .sub-menu,.menu .sub-menu .sub-menu,nav .sub-menu .sub-menu{top:0!important;left:100%!important;}
    }';
    wp_register_style('n-cmuk-desktop-menu-mobile-accordion', false, array(), '19.0.8');
    wp_enqueue_style('n-cmuk-desktop-menu-mobile-accordion');
    wp_add_inline_style('n-cmuk-desktop-menu-mobile-accordion', $css);
}
add_action('wp_enqueue_scripts', 'n_cmuk_desktop_menu_mobile_accordion', 130);


function o_cmuk_desktop_mobile_style_right_menu() {
    $css = '
    @media(min-width:1025px){
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{margin-left:auto!important;margin-right:0!important;width:auto!important;max-width:none!important;display:flex!important;justify-content:flex-end!important;}
      .cmuk-menu,.menu,nav ul{display:flex!important;justify-content:flex-end!important;align-items:stretch!important;width:auto!important;margin-left:auto!important;margin-right:0!important;}
      .cmuk-menu>li>a,.menu>li>a,nav ul>li>a{color:#ffffff!important;background:transparent!important;font-weight:700!important;text-decoration:none!important;}
      .cmuk-menu>li>a:hover,.menu>li>a:hover,nav ul>li>a:hover,.cmuk-menu>li>a:focus,.menu>li>a:focus,nav ul>li>a:focus{background:rgba(0,0,0,.12)!important;color:#ffffff!important;text-decoration:none!important;}
      .cmuk-menu .sub-menu,.menu .sub-menu,nav .sub-menu{background:var(--cmuk-header-colour,#1d70b8)!important;color:#ffffff!important;border:0!important;border-top:1px solid rgba(255,255,255,.3)!important;box-shadow:none!important;min-width:260px!important;max-width:360px!important;padding:0!important;}
      .cmuk-menu li.cmuk-submenu-open>.sub-menu,.menu li.cmuk-submenu-open>.sub-menu,nav li.cmuk-submenu-open>.sub-menu{display:block!important;}
      .cmuk-menu .sub-menu li,.menu .sub-menu li,nav .sub-menu li{border-bottom:1px solid rgba(255,255,255,.3)!important;background:transparent!important;}
      .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,nav .sub-menu li>a{color:#ffffff!important;background:transparent!important;font-weight:700!important;font-size:18px!important;line-height:1.25!important;min-height:56px!important;padding:16px 18px!important;text-decoration:none!important;white-space:normal!important;}
      .cmuk-menu .sub-menu li>a:hover,.menu .sub-menu li>a:hover,nav .sub-menu li>a:hover,.cmuk-menu .sub-menu li>a:focus,.menu .sub-menu li>a:focus,nav .sub-menu li>a:focus{background:rgba(0,0,0,.12)!important;color:#ffffff!important;text-decoration:none!important;}
      .cmuk-menu .sub-menu .sub-menu,.menu .sub-menu .sub-menu,nav .sub-menu .sub-menu{background:var(--cmuk-header-colour,#1d70b8)!important;border-left:1px solid rgba(255,255,255,.3)!important;}
      .cmuk-submenu-toggle{color:#ffffff!important;}
    }';
    wp_register_style('o-cmuk-desktop-mobile-style-right-menu', false, array(), '19.0.9');
    wp_enqueue_style('o-cmuk-desktop-mobile-style-right-menu');
    wp_add_inline_style('o-cmuk-desktop-mobile-style-right-menu', $css);
}
add_action('wp_enqueue_scripts', 'o_cmuk_desktop_mobile_style_right_menu', 140);


function p_cmuk_desktop_stacked_accordion() {
    $css = '
    @media(min-width:1025px){
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{margin-left:auto!important;margin-right:0!important;display:flex!important;justify-content:flex-end!important;width:auto!important;max-width:none!important;}
      .cmuk-menu,.menu,nav ul{display:flex!important;justify-content:flex-end!important;align-items:stretch!important;width:auto!important;margin-left:auto!important;margin-right:0!important;}
      .cmuk-menu>li,.menu>li,nav ul>li{position:relative!important;width:auto!important;}
      .cmuk-menu>li>.sub-menu,.menu>li>.sub-menu,nav ul>li>.sub-menu{position:absolute!important;top:100%!important;left:0!important;min-width:260px!important;max-width:360px!important;width:max-content!important;background:var(--cmuk-header-colour,#1d70b8)!important;color:#fff!important;border:0!important;border-top:1px solid rgba(255,255,255,.3)!important;box-shadow:none!important;padding:0!important;margin:0!important;z-index:99999!important;}
      .cmuk-menu .sub-menu .sub-menu,.menu .sub-menu .sub-menu,nav .sub-menu .sub-menu{position:static!important;top:auto!important;left:auto!important;min-width:0!important;max-width:none!important;width:100%!important;background:var(--cmuk-header-colour,#1d70b8)!important;border:0!important;border-top:1px solid rgba(255,255,255,.3)!important;box-shadow:none!important;padding:0!important;margin:0!important;}
      .cmuk-menu li:hover>.sub-menu,.menu li:hover>.sub-menu,nav li:hover>.sub-menu,.cmuk-menu li:focus-within>.sub-menu,.menu li:focus-within>.sub-menu,nav li:focus-within>.sub-menu{display:none!important;}
      .cmuk-menu li.cmuk-submenu-open>.sub-menu,.menu li.cmuk-submenu-open>.sub-menu,nav li.cmuk-submenu-open>.sub-menu{display:block!important;}
      .cmuk-menu .sub-menu li,.menu .sub-menu li,nav .sub-menu li{display:block!important;width:100%!important;border-bottom:1px solid rgba(255,255,255,.3)!important;background:transparent!important;position:relative!important;}
      .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,nav .sub-menu li>a{display:flex!important;align-items:center!important;justify-content:space-between!important;width:100%!important;min-height:56px!important;padding:16px 18px!important;box-sizing:border-box!important;color:#fff!important;background:transparent!important;font-weight:700!important;font-size:18px!important;line-height:1.25!important;white-space:normal!important;text-decoration:none!important;}
      .cmuk-submenu-toggle{display:inline-flex!important;align-items:center!important;justify-content:center!important;width:36px!important;height:36px!important;min-width:36px!important;flex:0 0 36px!important;margin-left:auto!important;color:#fff!important;}
      .cmuk-submenu-toggle:before{content:""!important;display:block!important;width:0!important;height:0!important;border-left:7px solid transparent!important;border-right:7px solid transparent!important;border-top:8px solid currentColor!important;border-bottom:0!important;}
      .cmuk-submenu-open>a .cmuk-submenu-toggle:before{border-top:0!important;border-bottom:8px solid currentColor!important;}
      .cmuk-menu .sub-menu a:before,.menu .sub-menu a:before,nav .sub-menu a:before{content:""!important;display:none!important;}
    }';
    wp_register_style('p-cmuk-desktop-stacked-accordion', false, array(), '19.0.10');
    wp_enqueue_style('p-cmuk-desktop-stacked-accordion');
    wp_add_inline_style('p-cmuk-desktop-stacked-accordion', $css);
}
add_action('wp_enqueue_scripts', 'p_cmuk_desktop_stacked_accordion', 150);


function q_cmuk_exact_mobile_accordion_controls() {
    $css = '
      .cmuk-submenu-toggle{display:inline-flex!important;align-items:center!important;justify-content:center!important;width:36px!important;height:36px!important;min-width:36px!important;flex:0 0 36px!important;margin-left:auto!important;color:inherit!important;cursor:pointer!important;pointer-events:auto!important;position:relative!important;}
      .cmuk-submenu-toggle:before{content:""!important;display:block!important;width:0!important;height:0!important;border-left:7px solid transparent!important;border-right:7px solid transparent!important;border-top:8px solid currentColor!important;border-bottom:0!important;}
      .cmuk-submenu-open>a .cmuk-submenu-toggle:before{border-top:0!important;border-bottom:8px solid currentColor!important;}
      .cmuk-has-submenu>.sub-menu,.menu-item-has-children>.sub-menu,.page_item_has_children>.sub-menu{display:none!important;}
      .cmuk-has-submenu.cmuk-submenu-open>.sub-menu,.menu-item-has-children.cmuk-submenu-open>.sub-menu,.page_item_has_children.cmuk-submenu-open>.sub-menu{display:block!important;}
      .cmuk-has-submenu:hover>.sub-menu,.menu-item-has-children:hover>.sub-menu,.page_item_has_children:hover>.sub-menu,.cmuk-has-submenu:focus-within>.sub-menu,.menu-item-has-children:focus-within>.sub-menu,.page_item_has_children:focus-within>.sub-menu{display:none!important;}
      .cmuk-has-submenu.cmuk-submenu-open:hover>.sub-menu,.menu-item-has-children.cmuk-submenu-open:hover>.sub-menu,.page_item_has_children.cmuk-submenu-open:hover>.sub-menu,.cmuk-has-submenu.cmuk-submenu-open:focus-within>.sub-menu,.menu-item-has-children.cmuk-submenu-open:focus-within>.sub-menu,.page_item_has_children.cmuk-submenu-open:focus-within>.sub-menu{display:block!important;}
    ';
    wp_register_style('q-cmuk-exact-mobile-accordion-controls', false, array(), '19.0.11');
    wp_enqueue_style('q-cmuk-exact-mobile-accordion-controls');
    wp_add_inline_style('q-cmuk-exact-mobile-accordion-controls', $css);
}
add_action('wp_enqueue_scripts', 'q_cmuk_exact_mobile_accordion_controls', 160);


function r_cmuk_tablet_accordion_onscreen() {
    $css = '
    @media(min-width:768px) and (max-width:1024px){
      html,body{overflow-x:hidden!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{width:100%!important;max-width:100%!important;box-sizing:border-box!important;overflow-x:hidden!important;}
      .cmuk-menu,.menu,nav ul{width:100%!important;max-width:100%!important;box-sizing:border-box!important;overflow-x:hidden!important;}
      .cmuk-menu li,.menu li,nav ul li{width:100%!important;max-width:100%!important;box-sizing:border-box!important;position:relative!important;}
      .cmuk-menu li>a,.menu li>a,nav ul li>a{width:100%!important;max-width:100%!important;box-sizing:border-box!important;overflow-wrap:anywhere!important;white-space:normal!important;}
      .cmuk-menu .sub-menu,.menu .sub-menu,nav .sub-menu{position:static!important;left:auto!important;right:auto!important;top:auto!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;transform:none!important;overflow-x:hidden!important;margin-left:0!important;margin-right:0!important;}
      .cmuk-menu .sub-menu .sub-menu,.menu .sub-menu .sub-menu,nav .sub-menu .sub-menu{position:static!important;left:auto!important;right:auto!important;width:100%!important;max-width:100%!important;min-width:0!important;transform:none!important;}
      .cmuk-menu li.cmuk-submenu-open>.sub-menu,.menu li.cmuk-submenu-open>.sub-menu,nav li.cmuk-submenu-open>.sub-menu{display:block!important;}
      .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,nav .sub-menu li>a{width:100%!important;max-width:100%!important;box-sizing:border-box!important;white-space:normal!important;overflow-wrap:anywhere!important;}
      .cmuk-submenu-toggle{flex:0 0 36px!important;min-width:36px!important;}
    }
    @media(max-width:1024px){.cmuk-menu .sub-menu,.menu .sub-menu,nav .sub-menu{max-width:100vw!important;}}';
    wp_register_style('r-cmuk-tablet-accordion-onscreen', false, array(), '19.0.12');
    wp_enqueue_style('r-cmuk-tablet-accordion-onscreen');
    wp_add_inline_style('r-cmuk-tablet-accordion-onscreen', $css);
}
add_action('wp_enqueue_scripts', 'r_cmuk_tablet_accordion_onscreen', 170);


function s_cmuk_dropdown_contained() {
    $css = '
      html,body{overflow-x:hidden!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{box-sizing:border-box!important;max-width:100vw!important;}
      @media(min-width:768px) and (max-width:1366px){
        .cmuk-primary-navigation,.cmuk-gov-nav,header nav{width:100%!important;max-width:100vw!important;overflow:visible!important;box-sizing:border-box!important;}
        .cmuk-menu,.menu,header nav ul{max-width:100%!important;box-sizing:border-box!important;overflow:visible!important;}
        .cmuk-menu>li,.menu>li,header nav ul>li{position:relative!important;}
        .cmuk-menu>li>.sub-menu,.menu>li>.sub-menu,header nav ul>li>.sub-menu{position:absolute!important;top:100%!important;left:auto!important;right:0!important;width:min(320px, calc(100vw - 32px))!important;max-width:calc(100vw - 32px)!important;min-width:0!important;box-sizing:border-box!important;transform:none!important;overflow-x:hidden!important;background:var(--cmuk-header-colour,#1d70b8)!important;color:#fff!important;z-index:99999!important;}
        .cmuk-menu .sub-menu .sub-menu,.menu .sub-menu .sub-menu,header nav .sub-menu .sub-menu{position:static!important;left:auto!important;right:auto!important;top:auto!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;transform:none!important;overflow-x:hidden!important;background:var(--cmuk-header-colour,#1d70b8)!important;}
        .cmuk-menu .sub-menu li,.menu .sub-menu li,header nav .sub-menu li{width:100%!important;max-width:100%!important;box-sizing:border-box!important;}
        .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,header nav .sub-menu li>a{width:100%!important;max-width:100%!important;box-sizing:border-box!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;}
        .cmuk-menu li.cmuk-submenu-open>.sub-menu,.menu li.cmuk-submenu-open>.sub-menu,header nav li.cmuk-submenu-open>.sub-menu{display:block!important;}
      }
      @media(min-width:1367px){
        .cmuk-menu>li,.menu>li,header nav ul>li{position:relative!important;}
        .cmuk-menu>li>.sub-menu,.menu>li>.sub-menu,header nav ul>li>.sub-menu{max-width:min(360px, calc(100vw - 32px))!important;box-sizing:border-box!important;overflow-x:hidden!important;}
        .cmuk-menu>li:last-child>.sub-menu,.cmuk-menu>li:nth-last-child(2)>.sub-menu,.menu>li:last-child>.sub-menu,.menu>li:nth-last-child(2)>.sub-menu,header nav ul>li:last-child>.sub-menu,header nav ul>li:nth-last-child(2)>.sub-menu{left:auto!important;right:0!important;}
        .cmuk-menu .sub-menu .sub-menu,.menu .sub-menu .sub-menu,header nav .sub-menu .sub-menu{position:static!important;left:auto!important;right:auto!important;width:100%!important;max-width:100%!important;}
      }';
    wp_register_style('s-cmuk-dropdown-contained', false, array(), '19.0.13');
    wp_enqueue_style('s-cmuk-dropdown-contained');
    wp_add_inline_style('s-cmuk-dropdown-contained', $css);
}
add_action('wp_enqueue_scripts', 's_cmuk_dropdown_contained', 180);


function t_cmuk_header_menu_alignment_spacing() {
    $css = '
    :root{--cmuk-header-edge-space:32px;--cmuk-menu-item-gap:0px;--cmuk-menu-link-x:14px;}
    @media(min-width:768px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner{max-width:none!important;width:100%!important;box-sizing:border-box!important;padding-left:var(--cmuk-header-edge-space)!important;padding-right:var(--cmuk-header-edge-space)!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:24px!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,header .site-title,header .cmuk-site-title{order:2!important;margin-left:auto!important;margin-right:0!important;text-align:right!important;white-space:nowrap!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{order:1!important;margin-left:0!important;margin-right:auto!important;width:auto!important;max-width:calc(100% - 260px)!important;display:flex!important;justify-content:flex-start!important;align-items:center!important;box-sizing:border-box!important;overflow:visible!important;}
      .cmuk-menu,.menu,header nav ul{display:flex!important;align-items:stretch!important;justify-content:flex-start!important;gap:var(--cmuk-menu-item-gap)!important;width:auto!important;margin:0!important;padding:0!important;box-sizing:border-box!important;}
      .cmuk-menu>li,.menu>li,header nav ul>li{display:block!important;width:auto!important;margin:0!important;padding:0!important;border-bottom:0!important;position:relative!important;box-sizing:border-box!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{display:flex!important;align-items:center!important;justify-content:center!important;gap:8px!important;min-height:56px!important;height:56px!important;padding:0 var(--cmuk-menu-link-x)!important;margin:0!important;box-sizing:border-box!important;white-space:nowrap!important;line-height:1.2!important;}
      .cmuk-submenu-toggle{width:22px!important;height:22px!important;min-width:22px!important;flex:0 0 22px!important;margin-left:6px!important;}
      .cmuk-menu li:not(.cmuk-has-submenu)>a:after,.menu li:not(.cmuk-has-submenu):not(.menu-item-has-children):not(.page_item_has_children)>a:after,header nav ul li:not(.cmuk-has-submenu):not(.menu-item-has-children):not(.page_item_has_children)>a:after{content:none!important;display:none!important;width:0!important;min-width:0!important;margin:0!important;}
      .cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,header nav .sub-menu li>a{justify-content:space-between!important;min-height:52px!important;height:auto!important;padding:14px 16px!important;margin:0!important;gap:8px!important;}
    }
    @media(min-width:768px) and (max-width:1024px){
      :root{--cmuk-header-edge-space:24px;--cmuk-menu-link-x:12px;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{max-width:calc(100% - 220px)!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{min-height:54px!important;height:54px!important;font-size:18px!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,header .site-title,header .cmuk-site-title{font-size:32px!important;}
    }
    @media(min-width:1025px){
      :root{--cmuk-header-edge-space:48px;--cmuk-menu-link-x:16px;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{max-width:calc(100% - 340px)!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{min-height:58px!important;height:58px!important;font-size:16px!important;}
    }';
    wp_register_style('t-cmuk-header-menu-alignment-spacing', false, array(), '19.0.14');
    wp_enqueue_style('t-cmuk-header-menu-alignment-spacing');
    wp_add_inline_style('t-cmuk-header-menu-alignment-spacing', $css);
}
add_action('wp_enqueue_scripts', 't_cmuk_header_menu_alignment_spacing', 190);


function u_cmuk_header_final_positioning() {
    $css='
    @media(min-width:768px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner{display:flex!important;align-items:center!important;justify-content:space-between!important;padding-left:48px!important;padding-right:48px!important;gap:32px!important;width:100%!important;box-sizing:border-box!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{order:1!important;margin:0!important;margin-right:auto!important;text-align:left!important;flex:0 0 auto!important;white-space:nowrap!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{order:2!important;margin-left:auto!important;margin-right:0!important;display:flex!important;justify-content:flex-end!important;align-items:center!important;flex:0 1 auto!important;max-width:none!important;width:auto!important;}
      .cmuk-menu,.menu,header nav ul{display:flex!important;align-items:center!important;justify-content:flex-end!important;width:auto!important;margin:0!important;padding:0!important;gap:0!important;}
      .cmuk-menu>li,.menu>li,header nav ul>li{width:auto!important;margin:0!important;padding:0!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{display:flex!important;align-items:center!important;justify-content:center!important;gap:8px!important;min-height:58px!important;padding:0 16px!important;white-space:nowrap!important;box-sizing:border-box!important;}
      .cmuk-submenu-toggle{margin-left:6px!important;width:20px!important;min-width:20px!important;flex:0 0 20px!important;}
      .cmuk-menu>li>.sub-menu,.menu>li>.sub-menu,header nav ul>li>.sub-menu{right:0!important;left:auto!important;max-width:min(340px, calc(100vw - 48px))!important;}
    }
    @media(min-width:768px) and (max-width:1024px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner{padding-left:24px!important;padding-right:24px!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{padding:0 12px!important;font-size:18px!important;}
    }';
    wp_register_style('u-cmuk-header-final-positioning', false, array(), '19.0.15');
    wp_enqueue_style('u-cmuk-header-final-positioning');
    wp_add_inline_style('u-cmuk-header-final-positioning', $css);
}
add_action('wp_enqueue_scripts', 'u_cmuk_header_final_positioning', 200);


function v_cmuk_edge_alignment() {
    $css='
    @media(min-width:768px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner{display:flex!important;align-items:center!important;justify-content:space-between!important;width:100%!important;max-width:none!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;gap:0!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{order:1!important;margin:0!important;margin-right:auto!important;padding-right:10px!important;text-align:left!important;justify-content:flex-start!important;align-self:center!important;flex:0 0 auto!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav{order:2!important;margin-left:auto!important;margin-right:0!important;padding-left:10px!important;display:flex!important;justify-content:flex-end!important;align-items:center!important;width:auto!important;max-width:none!important;flex:0 0 auto!important;}
      .cmuk-menu,.menu,header nav ul{display:flex!important;justify-content:flex-end!important;align-items:center!important;margin:0!important;padding:0!important;gap:0!important;width:auto!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{min-height:58px!important;padding:0 14px!important;display:flex!important;align-items:center!important;justify-content:center!important;gap:8px!important;white-space:nowrap!important;}
      .cmuk-submenu-toggle{margin-left:6px!important;}
    }';
    wp_register_style('v-cmuk-edge-alignment', false, array(), '19.0.16');
    wp_enqueue_style('v-cmuk-edge-alignment');
    wp_add_inline_style('v-cmuk-edge-alignment', $css);
}
add_action('wp_enqueue_scripts', 'v_cmuk_edge_alignment', 210);


add_action('wp_enqueue_scripts', function(){
    $css = '@media (min-width:1025px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,.site-header,.site-branding{width:100%!important;max-width:100%!important;padding-left:10px!important;padding-right:10px!important;margin:0!important;display:flex!important;align-items:center!important;justify-content:space-between!important;box-sizing:border-box!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{margin-left:0!important;margin-right:auto!important;padding-right:10px!important;text-align:left!important;justify-content:flex-start!important;align-self:center!important;position:relative!important;left:0!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav,.main-navigation{margin-left:auto!important;margin-right:0!important;padding-left:10px!important;justify-content:flex-end!important;text-align:right!important;position:relative!important;right:0!important;width:auto!important;max-width:none!important;}
      .cmuk-menu,.menu,.main-navigation ul,header nav ul{justify-content:flex-end!important;margin-left:auto!important;margin-right:0!important;width:auto!important;}
    }';
    wp_register_style("v-force-desktop-align", false);
    wp_enqueue_style("v-force-desktop-align");
    wp_add_inline_style("v-force-desktop-align",$css);
},999);


function w_cmuk_elementor_desktop_alignment(){
    $css='@media(min-width:1025px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100%!important;max-width:none!important;display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:space-between!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{order:1!important;flex:1 1 auto!important;display:flex!important;justify-content:flex-start!important;align-items:center!important;text-align:left!important;margin:0!important;padding-right:10px!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,header nav,.main-navigation{order:2!important;flex:1 1 auto!important;display:flex!important;justify-content:flex-end!important;align-items:center!important;text-align:right!important;margin:0!important;padding-left:10px!important;width:auto!important;max-width:none!important;}
      .cmuk-menu,.menu,header nav ul,.main-navigation ul{display:flex!important;justify-content:flex-end!important;align-items:center!important;width:auto!important;margin:0!important;padding:0!important;gap:0!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a,.main-navigation ul>li>a{min-height:58px!important;padding:0 14px!important;display:flex!important;align-items:center!important;justify-content:center!important;white-space:nowrap!important;gap:8px!important;}
    }';
    wp_register_style('w-cmuk-elementor-desktop-alignment', false, array(), '19.0.17');
    wp_enqueue_style('w-cmuk-elementor-desktop-alignment');
    wp_add_inline_style('w-cmuk-elementor-desktop-alignment', $css);
}
add_action('wp_enqueue_scripts','w_cmuk_elementor_desktop_alignment',220);


function x_cmuk_mobile_menu_16px() {
    $css='
    @media(max-width:1024px){
      .cmuk-menu-toggle,.cmuk-gov-header__toggle,header button[aria-controls]{font-size:16px!important;line-height:1.25!important;font-weight:700!important;}
      .cmuk-menu li>a,.menu li>a,header nav ul li>a,.cmuk-menu>li>a,.menu>li>a,header nav ul>li>a,.cmuk-menu .sub-menu li>a,.menu .sub-menu li>a,header nav .sub-menu li>a{font-size:16px!important;line-height:1.25!important;font-weight:700!important;min-height:48px!important;height:auto!important;padding-top:12px!important;padding-bottom:12px!important;box-sizing:border-box!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,header .site-title{font-size:32px!important;line-height:1.1!important;}
      .cmuk-submenu-toggle{width:28px!important;height:28px!important;min-width:28px!important;flex:0 0 28px!important;margin-left:8px!important;}
      .cmuk-submenu-toggle:before{border-left-width:6px!important;border-right-width:6px!important;border-top-width:7px!important;}
      .cmuk-submenu-open>a .cmuk-submenu-toggle:before{border-top:0!important;border-bottom-width:7px!important;}
    }';
    wp_register_style('x-cmuk-mobile-menu-16px', false, array(), '19.0.18');
    wp_enqueue_style('x-cmuk-mobile-menu-16px');
    wp_add_inline_style('x-cmuk-mobile-menu-16px', $css);
}
add_action('wp_enqueue_scripts','x_cmuk_mobile_menu_16px',230);


function y_cmuk_mobile_cleanup(){
    $css='
    @media(max-width:1024px){
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{font-size:16px!important;line-height:1.25!important;font-weight:700!important;}
      .cmuk-menu li,.menu li,header nav ul li{border-top:0!important;border-bottom:1px solid rgba(255,255,255,0.25)!important;}
      .cmuk-menu .sub-menu li:first-child,.menu .sub-menu li:first-child,header nav .sub-menu li:first-child{border-top:0!important;}
      .cmuk-menu .sub-menu,.menu .sub-menu,header nav .sub-menu{margin-top:0!important;padding-top:0!important;border-top:0!important;}
    }';
    wp_register_style('y-cmuk-mobile-cleanup', false, array(), '19.0.19');
    wp_enqueue_style('y-cmuk-mobile-cleanup');
    wp_add_inline_style('y-cmuk-mobile-cleanup', $css);
}
add_action('wp_enqueue_scripts','y_cmuk_mobile_cleanup',240);


function z_cmuk_thin_divider_fix(){
    $css='
    @media(max-width:1024px){
      .cmuk-menu li,.menu li,header nav ul li{border-bottom:1px solid rgba(255,255,255,0.18)!important;box-shadow:none!important;}
      .cmuk-menu .sub-menu li,.menu .sub-menu li,header nav .sub-menu li{border-bottom:1px solid rgba(255,255,255,0.18)!important;box-shadow:none!important;}
    }';
    wp_register_style('z-cmuk-thin-divider-fix', false, array(), '19.0.20');
    wp_enqueue_style('z-cmuk-thin-divider-fix');
    wp_add_inline_style('z-cmuk-thin-divider-fix', $css);
}
add_action('wp_enqueue_scripts','z_cmuk_thin_divider_fix',250);


function aa_cmuk_uniform_dividers(){
    $css='
    .cmuk-menu li,.menu li,header nav ul li,.cmuk-menu .sub-menu li,.menu .sub-menu li,header nav .sub-menu li{
        border-top:0!important;
        border-bottom:1px solid rgba(255,255,255,0.18)!important;
        box-shadow:none!important;
        outline:none!important;
    }
    .cmuk-menu li:before,.cmuk-menu li:after,.menu li:before,.menu li:after,header nav ul li:before,header nav ul li:after{
        display:none!important;
        content:none!important;
        border:0!important;
        box-shadow:none!important;
    }
    .cmuk-menu .sub-menu,.menu .sub-menu,header nav .sub-menu{
        border-top:0!important;
        border-bottom:0!important;
        box-shadow:none!important;
    }';
    wp_register_style('aa-cmuk-uniform-dividers', false, array(), '19.0.21');
    wp_enqueue_style('aa-cmuk-uniform-dividers');
    wp_add_inline_style('aa-cmuk-uniform-dividers', $css);
}
add_action('wp_enqueue_scripts','aa_cmuk_uniform_dividers',260);


function ab_cmuk_remove_hover_divider(){
    $css='
    .cmuk-menu li:hover,
    .cmuk-menu li:focus,
    .cmuk-menu li:active,
    .menu li:hover,
    .menu li:focus,
    .menu li:active,
    header nav ul li:hover,
    header nav ul li:focus,
    header nav ul li:active{
        border-top:0!important;
        border-bottom:1px solid rgba(255,255,255,0.18)!important;
        box-shadow:none!important;
        outline:none!important;
    }

    .cmuk-menu li:hover:before,
    .cmuk-menu li:hover:after,
    .menu li:hover:before,
    .menu li:hover:after,
    header nav ul li:hover:before,
    header nav ul li:hover:after{
        display:none!important;
        content:none!important;
        border:0!important;
        box-shadow:none!important;
    }';
    wp_register_style('ab-cmuk-hover-divider-fix', false, array(), '19.0.22');
    wp_enqueue_style('ab-cmuk-hover-divider-fix');
    wp_add_inline_style('ab-cmuk-hover-divider-fix', $css);
}
add_action('wp_enqueue_scripts','ab_cmuk_remove_hover_divider',270);


function ac_cmuk_force_remove_hover_border(){
    $css='
    .cmuk-menu li,
    .cmuk-menu li:hover,
    .cmuk-menu li:focus,
    .cmuk-menu li:active,
    .cmuk-menu li.current-menu-item,
    .cmuk-menu li.current_page_item,
    .menu li,
    .menu li:hover,
    .menu li:focus,
    .menu li:active,
    .menu li.current-menu-item,
    .menu li.current_page_item,
    header nav ul li,
    header nav ul li:hover,
    header nav ul li:focus,
    header nav ul li:active,
    header nav ul li.current-menu-item,
    header nav ul li.current_page_item{
        border-top:none!important;
        border-left:none!important;
        border-right:none!important;
        border-bottom:1px solid rgba(255,255,255,0.18)!important;
        background-image:none!important;
        box-shadow:none!important;
        outline:none!important;
    }

    .cmuk-menu li:before,
    .cmuk-menu li:after,
    .cmuk-menu li:hover:before,
    .cmuk-menu li:hover:after,
    .cmuk-menu li:focus:before,
    .cmuk-menu li:focus:after,
    .menu li:before,
    .menu li:after,
    .menu li:hover:before,
    .menu li:hover:after,
    .menu li:focus:before,
    .menu li:focus:after,
    header nav ul li:before,
    header nav ul li:after,
    header nav ul li:hover:before,
    header nav ul li:hover:after,
    header nav ul li:focus:before,
    header nav ul li:focus:after{
        content:none!important;
        display:none!important;
        border:none!important;
        background:none!important;
        box-shadow:none!important;
        opacity:0!important;
    }

    .cmuk-menu li a,
    .cmuk-menu li a:hover,
    .cmuk-menu li a:focus,
    .menu li a,
    .menu li a:hover,
    .menu li a:focus,
    header nav ul li a,
    header nav ul li a:hover,
    header nav ul li a:focus{
        border:none!important;
        box-shadow:none!important;
        text-decoration:none!important;
        background-image:none!important;
    }';
    wp_register_style('ac-cmuk-force-remove-hover-border', false, array(), '19.0.23');
    wp_enqueue_style('ac-cmuk-force-remove-hover-border');
    wp_add_inline_style('ac-cmuk-force-remove-hover-border', $css);
}
add_action('wp_enqueue_scripts','ac_cmuk_force_remove_hover_border',280);


function ad_cmuk_remove_all_menu_states() {
    $css = '
    .cmuk-menu li,.cmuk-menu li:hover,.cmuk-menu li:focus,.cmuk-menu li:focus-within,.cmuk-menu li:active,.cmuk-menu li.current-menu-item,.cmuk-menu li.current_page_item,.cmuk-menu li.current-menu-ancestor,.cmuk-menu li.current-menu-parent,.menu li,.menu li:hover,.menu li:focus,.menu li:focus-within,.menu li:active,.menu li.current-menu-item,.menu li.current_page_item,.menu li.current-menu-ancestor,.menu li.current-menu-parent,header nav ul li,header nav ul li:hover,header nav ul li:focus,header nav ul li:focus-within,header nav ul li:active,header nav ul li.current-menu-item,header nav ul li.current_page_item,header nav ul li.current-menu-ancestor,header nav ul li.current-menu-parent{background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;outline:none!important;border-top:0!important;border-left:0!important;border-right:0!important;border-bottom:1px solid rgba(255,255,255,0.18)!important;filter:none!important;}
    .cmuk-menu a,.cmuk-menu a:link,.cmuk-menu a:visited,.cmuk-menu a:hover,.cmuk-menu a:focus,.cmuk-menu a:focus-visible,.cmuk-menu a:active,.cmuk-menu .current-menu-item>a,.cmuk-menu .current_page_item>a,.cmuk-menu .current-menu-ancestor>a,.cmuk-menu .current-menu-parent>a,.menu a,.menu a:link,.menu a:visited,.menu a:hover,.menu a:focus,.menu a:focus-visible,.menu a:active,.menu .current-menu-item>a,.menu .current_page_item>a,.menu .current-menu-ancestor>a,.menu .current-menu-parent>a,header nav ul a,header nav ul a:link,header nav ul a:visited,header nav ul a:hover,header nav ul a:focus,header nav ul a:focus-visible,header nav ul a:active,header nav ul .current-menu-item>a,header nav ul .current_page_item>a,header nav ul .current-menu-ancestor>a,header nav ul .current-menu-parent>a{background:transparent!important;background-color:transparent!important;background-image:none!important;color:inherit!important;text-decoration:none!important;box-shadow:none!important;outline:none!important;border:0!important;filter:none!important;}
    .cmuk-menu li:before,.cmuk-menu li:after,.cmuk-menu li:hover:before,.cmuk-menu li:hover:after,.cmuk-menu li:focus:before,.cmuk-menu li:focus:after,.cmuk-menu li:focus-within:before,.cmuk-menu li:focus-within:after,.cmuk-menu li:active:before,.cmuk-menu li:active:after,.cmuk-menu a:before,.cmuk-menu a:after,.cmuk-menu a:hover:before,.cmuk-menu a:hover:after,.cmuk-menu a:focus:before,.cmuk-menu a:focus:after,.cmuk-menu a:active:before,.cmuk-menu a:active:after,.menu li:before,.menu li:after,.menu li:hover:before,.menu li:hover:after,.menu li:focus:before,.menu li:focus:after,.menu li:focus-within:before,.menu li:focus-within:after,.menu li:active:before,.menu li:active:after,.menu a:before,.menu a:after,.menu a:hover:before,.menu a:hover:after,.menu a:focus:before,.menu a:focus:after,.menu a:active:before,.menu a:active:after,header nav ul li:before,header nav ul li:after,header nav ul li:hover:before,header nav ul li:hover:after,header nav ul li:focus:before,header nav ul li:focus:after,header nav ul li:focus-within:before,header nav ul li:focus-within:after,header nav ul li:active:before,header nav ul li:active:after,header nav ul a:before,header nav ul a:after,header nav ul a:hover:before,header nav ul a:hover:after,header nav ul a:focus:before,header nav ul a:focus:after,header nav ul a:active:before,header nav ul a:active:after{content:none!important;display:none!important;visibility:hidden!important;opacity:0!important;background:none!important;background-color:transparent!important;background-image:none!important;border:0!important;box-shadow:none!important;outline:0!important;}
    .cmuk-submenu-open,.cmuk-submenu-open:hover,.cmuk-submenu-open:focus,.cmuk-submenu-open:focus-within,.cmuk-submenu-open:active{background:transparent!important;background-color:transparent!important;box-shadow:none!important;outline:none!important;}
    .cmuk-menu .sub-menu,.menu .sub-menu,header nav .sub-menu{border-top:0!important;border-bottom:0!important;box-shadow:none!important;}';
    wp_register_style('ad-cmuk-remove-all-menu-states', false, array(), '19.0.24');
    wp_enqueue_style('ad-cmuk-remove-all-menu-states');
    wp_add_inline_style('ad-cmuk-remove-all-menu-states', $css);
}
add_action('wp_enqueue_scripts','ad_cmuk_remove_all_menu_states',999);


function ae_cmuk_footer_style_alignment(){
    $css='
    @media(min-width:768px){

        .cmuk-header-inner,
        .cmuk-gov-header__inner,
        header .cmuk-header-inner,
        header .site-header-inner{
            width:100%!important;
            max-width:none!important;
            margin:0 auto!important;
            padding-left:10px!important;
            padding-right:10px!important;
            box-sizing:border-box!important;

            display:flex!important;
            align-items:center!important;
            justify-content:space-between!important;
        }

        .cmuk-site-title,
        .cmuk-gov-header__brand,
        .site-title,
        header .site-title{
            margin:0!important;
            padding:0!important;
            text-align:left!important;

            display:flex!important;
            align-items:center!important;
            justify-content:flex-start!important;

            flex:1 1 auto!important;
        }

        .cmuk-primary-navigation,
        .cmuk-gov-nav,
        .main-navigation,
        header nav{
            margin:0!important;
            padding:0!important;

            display:flex!important;
            align-items:center!important;
            justify-content:flex-end!important;

            flex:1 1 auto!important;
            text-align:right!important;
        }

        .cmuk-menu,
        .menu,
        .main-navigation ul,
        header nav ul{
            width:auto!important;

            display:flex!important;
            align-items:center!important;
            justify-content:flex-end!important;

            margin:0!important;
            padding:0!important;
            gap:0!important;
        }
    }';
    wp_register_style('ae-cmuk-footer-style-alignment', false, array(), '19.0.25');
    wp_enqueue_style('ae-cmuk-footer-style-alignment');
    wp_add_inline_style('ae-cmuk-footer-style-alignment', $css);
}
add_action('wp_enqueue_scripts','ae_cmuk_footer_style_alignment',290);


/**
 * AF revision: separate site title and menu bar alignment controls.
 * Uses same idea as footer alignment, with 10px desktop edge padding.
 */
function af_cmuk_sanitize_alignment($value) {
    return in_array($value, array('left', 'center', 'right'), true) ? $value : 'left';
}

function af_cmuk_title_menu_alignment_customize_register($wp_customize) {
    $section = 'j_cmuk_theme_settings';

    if (!$wp_customize->get_section($section)) {
        $wp_customize->add_section($section, array(
            'title' => __('CMUK Theme Settings', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'priority' => 30,
        ));
    }

    $wp_customize->add_setting('af_cmuk_site_title_alignment', array(
        'default' => 'left',
        'sanitize_callback' => 'af_cmuk_sanitize_alignment',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control('af_cmuk_site_title_alignment', array(
        'label' => __('', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'description' => __('Desktop only. .', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => $section,
        'type' => 'select',
        'choices' => array(
            'left' => __('Left', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'center' => __('Center', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'right' => __('Right', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
        ),
    ));

    $wp_customize->add_setting('af_cmuk_menu_bar_alignment', array(
        'default' => 'right',
        'sanitize_callback' => 'af_cmuk_sanitize_alignment',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control('af_cmuk_menu_bar_alignment', array(
        'label' => __('', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'description' => __('Desktop only. .', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => $section,
        'type' => 'select',
        'choices' => array(
            'left' => __('Left', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'center' => __('Center', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'right' => __('Right', 'af-cmuk-inspired-elementor-theme-v19-true-accordion'),
        ),
    ));
}
add_action('customize_register', 'af_cmuk_title_menu_alignment_customize_register', 50);

function af_cmuk_title_menu_alignment_css() {
    $title_alignment = get_theme_mod('af_cmuk_site_title_alignment', 'left');
    $menu_alignment = get_theme_mod('af_cmuk_menu_bar_alignment', 'right');

    if (!in_array($title_alignment, array('left', 'center', 'right'), true)) {
        $title_alignment = 'left';
    }

    if (!in_array($menu_alignment, array('left', 'center', 'right'), true)) {
        $menu_alignment = 'right';
    }

    $css = ':root{'
        . '--cmuk-site-title-alignment:' . esc_attr($title_alignment) . ';'
        . '--cmuk-menu-bar-alignment:' . esc_attr($menu_alignment) . ';'
        . '--cmuk-desktop-edge-padding:10px;'
        . '}'
        . '@media(min-width:1025px){'
        . '.cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100%!important;max-width:none!important;margin:0 auto!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;display:grid!important;grid-template-columns:1fr 1fr!important;align-items:center!important;gap:20px!important;}'
        . '.cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{grid-column:1!important;width:100%!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($title_alignment) . '!important;text-align:' . esc_attr($title_alignment) . '!important;box-sizing:border-box!important;white-space:nowrap!important;}'
        . '.cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{grid-column:2!important;width:100%!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu_alignment) . '!important;text-align:' . esc_attr($menu_alignment) . '!important;box-sizing:border-box!important;}'
        . '.cmuk-menu,.menu,.main-navigation ul,header nav ul{width:auto!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu_alignment) . '!important;gap:0!important;}'
        . '}';

    wp_register_style('af-cmuk-title-menu-alignment', false, array(), '19.0.26');
    wp_enqueue_style('af-cmuk-title-menu-alignment');
    wp_add_inline_style('af-cmuk-title-menu-alignment', $css);
}
add_action('wp_enqueue_scripts', 'af_cmuk_title_menu_alignment_css', 300);


/**
 * AG revision: Elementor-style responsive choose-control alignment.
 */
function ag_cmuk_alignment_to_justify($value, $default = 'left') {
    if (!in_array($value, array('left', 'center', 'right'), true)) {
        $value = $default;
    }

    if ($value === 'center') {
        return 'center';
    }

    if ($value === 'right') {
        return 'flex-end';
    }

    return 'flex-start';
}

function ag_cmuk_sanitize_alignment($value) {
    return in_array($value, array('left', 'center', 'right'), true) ? $value : 'left';
}

function ag_cmuk_header_alignment_customize_register($wp_customize) {
    $section = 'j_cmuk_theme_settings';

    if (!$wp_customize->get_section($section)) {
        $wp_customize->add_section($section, array(
            'title' => __('CMUK Theme Settings', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'priority' => 30,
        ));
    }

    $wp_customize->add_setting('ag_cmuk_site_title_alignment', array(
        'default' => 'left',
        'sanitize_callback' => 'ag_cmuk_sanitize_alignment',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control('ag_cmuk_site_title_alignment', array(
        'label' => __('', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'description' => __('. Uses 10px edge padding.', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => $section,
        'type' => 'radio',
        'choices' => array(
            'left' => __('Left', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'center' => __('Center', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'right' => __('Right', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
        ),
    ));

    $wp_customize->add_setting('ag_cmuk_menu_alignment', array(
        'default' => 'right',
        'sanitize_callback' => 'ag_cmuk_sanitize_alignment',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control('ag_cmuk_menu_alignment', array(
        'label' => __('', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'description' => __('. Uses 10px edge padding.', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
        'section' => $section,
        'type' => 'radio',
        'choices' => array(
            'left' => __('Left', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'center' => __('Center', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
            'right' => __('Right', 'ag-cmuk-inspired-elementor-theme-v19-true-accordion'),
        ),
    ));
}
add_action('customize_register', 'ag_cmuk_header_alignment_customize_register', 80);

function ag_cmuk_header_alignment_css() {
    $title = get_theme_mod('ag_cmuk_site_title_alignment', 'left');
    $menu = get_theme_mod('ag_cmuk_menu_alignment', 'right');

    $title_justify = ag_cmuk_alignment_to_justify($title, 'left');
    $menu_justify = ag_cmuk_alignment_to_justify($menu, 'right');

    $css = ':root{'
        . '--cmuk-title-justify:' . esc_attr($title_justify) . ';'
        . '--cmuk-menu-justify:' . esc_attr($menu_justify) . ';'
        . '--cmuk-header-edge-padding:10px;'
        . '}'
        . '@media(min-width:1025px){'
        . '.cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100%!important;max-width:none!important;margin:0!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:0!important;}'
        . '.cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{order:1!important;flex:1 1 50%!important;width:50%!important;max-width:50%!important;margin:0!important;padding:0 10px 0 0!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($title_justify) . '!important;white-space:nowrap!important;}'
        . '.cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{order:2!important;flex:1 1 50%!important;width:50%!important;max-width:50%!important;margin:0!important;padding:0 0 0 10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu_justify) . '!important;}'
        . '.cmuk-menu,.menu,.main-navigation ul,header nav ul{width:auto!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu_justify) . '!important;gap:0!important;}'
        . '}';

    wp_register_style('ag-cmuk-header-alignment', false, array(), '19.0.27');
    wp_enqueue_style('ag-cmuk-header-alignment');
    wp_add_inline_style('ag-cmuk-header-alignment', $css);
}
add_action('wp_enqueue_scripts', 'ag_cmuk_header_alignment_css', 1000);


function ah_cmuk_stretched_header_alignment() {
    $title = function_exists('ag_cmuk_alignment_to_justify') ? ag_cmuk_alignment_to_justify(get_theme_mod('ag_cmuk_site_title_alignment', 'left'), 'left') : 'flex-start';
    $menu = function_exists('ag_cmuk_alignment_to_justify') ? ag_cmuk_alignment_to_justify(get_theme_mod('ag_cmuk_menu_alignment', 'right'), 'right') : 'flex-end';

    $css = ':root{--cmuk-title-justify:' . esc_attr($title) . ';--cmuk-menu-justify:' . esc_attr($menu) . ';--cmuk-header-edge-padding:10px;}'
    . '@media(min-width:1025px){'
    . '.cmuk-site-header,.cmuk-gov-header,header.cmuk-site-header,header.cmuk-gov-header,body>header{width:100vw!important;max-width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important;box-sizing:border-box!important;left:auto!important;right:auto!important;}'
    . '.cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100%!important;max-width:100%!important;min-width:0!important;margin:0!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:0!important;}'
    . '.cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{order:1!important;flex:1 1 50%!important;width:50%!important;max-width:50%!important;min-width:0!important;margin:0!important;padding:0 10px 0 0!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($title) . '!important;white-space:nowrap!important;}'
    . '.cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{order:2!important;flex:1 1 50%!important;width:50%!important;max-width:50%!important;min-width:0!important;margin:0!important;padding:0 0 0 10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu) . '!important;}'
    . '.cmuk-menu,.menu,.main-navigation ul,header nav ul{width:auto!important;max-width:100%!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu) . '!important;gap:0!important;}'
    . '}';

    wp_register_style('ah-cmuk-stretched-header-alignment', false, array(), '19.0.28');
    wp_enqueue_style('ah-cmuk-stretched-header-alignment');
    wp_add_inline_style('ah-cmuk-stretched-header-alignment', $css);
}
add_action('wp_enqueue_scripts', 'ah_cmuk_stretched_header_alignment', 1100);


function aj_cmuk_full_width_header_title_menu() {
    $css = '
    .cmuk-site-header,.cmuk-gov-header,header.cmuk-site-header,header.cmuk-gov-header,body>header{width:100%!important;max-width:100%!important;box-sizing:border-box!important;margin-left:0!important;margin-right:0!important;}
    @media(max-width:1024px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100%!important;max-width:100%!important;min-width:0!important;margin:0!important;padding-left:32px!important;padding-right:32px!important;box-sizing:border-box!important;display:flex!important;align-items:stretch!important;justify-content:space-between!important;gap:0!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{flex:1 1 auto!important;min-width:0!important;margin:0!important;padding:0 16px 0 0!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:flex-start!important;min-height:64px!important;font-size:16px!important;line-height:1.25!important;font-weight:700!important;white-space:nowrap!important;}
      .cmuk-menu-toggle,.cmuk-gov-header__toggle,header button[aria-controls]{flex:0 0 auto!important;min-height:64px!important;margin:0!important;padding-left:16px!important;padding-right:16px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:16px!important;line-height:1.25!important;font-weight:700!important;border-left:1px solid rgba(255,255,255,0.25)!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{width:100%!important;max-width:100%!important;margin:0!important;padding-left:32px!important;padding-right:32px!important;box-sizing:border-box!important;}
      .cmuk-menu,.menu,.main-navigation ul,header nav ul{width:100%!important;max-width:100%!important;margin:0!important;padding:0!important;box-sizing:border-box!important;}
      .cmuk-menu li,.menu li,header nav ul li,.cmuk-menu li:hover,.cmuk-menu li:focus,.cmuk-menu li:focus-within,.cmuk-menu li:active,.cmuk-menu li.current-menu-item,.cmuk-menu li.current_page_item,.menu li:hover,.menu li:focus,.menu li:focus-within,.menu li:active,.menu li.current-menu-item,.menu li.current_page_item,header nav ul li:hover,header nav ul li:focus,header nav ul li:focus-within,header nav ul li:active,header nav ul li.current-menu-item,header nav ul li.current_page_item{border-top:0!important;border-left:0!important;border-right:0!important;border-bottom:1px solid rgba(255,255,255,0.22)!important;background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;outline:none!important;}
      .cmuk-menu a,.cmuk-menu a:hover,.cmuk-menu a:focus,.cmuk-menu a:active,.menu a,.menu a:hover,.menu a:focus,.menu a:active,header nav ul a,header nav ul a:hover,header nav ul a:focus,header nav ul a:active{background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;outline:none!important;text-decoration:none!important;border:0!important;}
      .cmuk-menu li:before,.cmuk-menu li:after,.cmuk-menu li:hover:before,.cmuk-menu li:hover:after,.cmuk-menu a:before,.cmuk-menu a:after,.cmuk-menu a:hover:before,.cmuk-menu a:hover:after,.menu li:before,.menu li:after,.menu li:hover:before,.menu li:hover:after,.menu a:before,.menu a:after,.menu a:hover:before,.menu a:hover:after,header nav ul li:before,header nav ul li:after,header nav ul li:hover:before,header nav ul li:hover:after,header nav ul a:before,header nav ul a:after,header nav ul a:hover:before,header nav ul a:hover:after{content:none!important;display:none!important;opacity:0!important;visibility:hidden!important;border:0!important;box-shadow:none!important;background:none!important;}
    }
    @media(min-width:1025px){
      .cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100%!important;max-width:100%!important;margin:0!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:0!important;}
      .cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{flex:1 1 50%!important;width:50%!important;max-width:50%!important;min-width:0!important;margin:0!important;padding:0 10px 0 0!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:flex-start!important;text-align:left!important;white-space:nowrap!important;}
      .cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{flex:1 1 50%!important;width:50%!important;max-width:50%!important;min-width:0!important;margin:0!important;padding:0 0 0 10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:flex-end!important;text-align:right!important;}
    }';
    wp_register_style('aj-cmuk-full-width-header-title-menu', false, array(), '19.0.30');
    wp_enqueue_style('aj-cmuk-full-width-header-title-menu');
    wp_add_inline_style('aj-cmuk-full-width-header-title-menu', $css);
}
add_action('wp_enqueue_scripts', 'aj_cmuk_full_width_header_title_menu', 1200);


function ak_cmuk_mobile_parent_dividers() {
    $css = '
    @media(max-width:1024px){
      .cmuk-menu>li,.menu>li,header nav ul>li,.cmuk-menu>li.cmuk-has-submenu,.menu>li.cmuk-has-submenu,header nav ul>li.cmuk-has-submenu,.cmuk-menu>li.menu-item-has-children,.menu>li.menu-item-has-children,header nav ul>li.menu-item-has-children{border-top:0!important;border-left:0!important;border-right:0!important;border-bottom:1px solid rgba(255,255,255,0.22)!important;box-shadow:none!important;outline:none!important;background:transparent!important;}
      .cmuk-menu>li>a,.menu>li>a,header nav ul>li>a{border:0!important;box-shadow:none!important;background:transparent!important;background-image:none!important;}
      .cmuk-menu .sub-menu>li,.menu .sub-menu>li,header nav .sub-menu>li{border-top:0!important;border-left:0!important;border-right:0!important;border-bottom:1px solid rgba(255,255,255,0.22)!important;box-shadow:none!important;outline:none!important;background:transparent!important;}
      .cmuk-menu>li:hover,.cmuk-menu>li:focus,.cmuk-menu>li:focus-within,.cmuk-menu>li:active,.cmuk-menu>li.current-menu-item,.cmuk-menu>li.current_page_item,.menu>li:hover,.menu>li:focus,.menu>li:focus-within,.menu>li:active,.menu>li.current-menu-item,.menu>li.current_page_item,header nav ul>li:hover,header nav ul>li:focus,header nav ul>li:focus-within,header nav ul>li:active,header nav ul>li.current-menu-item,header nav ul>li.current_page_item,.cmuk-menu .sub-menu>li:hover,.cmuk-menu .sub-menu>li:focus,.cmuk-menu .sub-menu>li:focus-within,.cmuk-menu .sub-menu>li:active,.menu .sub-menu>li:hover,.menu .sub-menu>li:focus,.menu .sub-menu>li:focus-within,.menu .sub-menu>li:active,header nav .sub-menu>li:hover,header nav .sub-menu>li:focus,header nav .sub-menu>li:focus-within,header nav .sub-menu>li:active{border-top:0!important;border-left:0!important;border-right:0!important;border-bottom:1px solid rgba(255,255,255,0.22)!important;background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;outline:none!important;}
      .cmuk-menu>li:before,.cmuk-menu>li:after,.cmuk-menu>li:hover:before,.cmuk-menu>li:hover:after,.menu>li:before,.menu>li:after,.menu>li:hover:before,.menu>li:hover:after,header nav ul>li:before,header nav ul>li:after,header nav ul>li:hover:before,header nav ul>li:hover:after{content:none!important;display:none!important;opacity:0!important;visibility:hidden!important;border:0!important;box-shadow:none!important;background:none!important;}
    }';
    wp_register_style('ak-cmuk-mobile-parent-dividers', false, array(), '19.0.31');
    wp_enqueue_style('ak-cmuk-mobile-parent-dividers');
    wp_add_inline_style('ak-cmuk-mobile-parent-dividers', $css);
}
add_action('wp_enqueue_scripts', 'ak_cmuk_mobile_parent_dividers', 1300);


function al_cmuk_alignment_to_justify($value, $default = 'left') {
    if (!in_array($value, array('left', 'center', 'right'), true)) {
        $value = $default;
    }
    if ($value === 'center') {
        return 'center';
    }
    if ($value === 'right') {
        return 'flex-end';
    }
    return 'flex-start';
}

function al_cmuk_sanitize_alignment($value) {
    return in_array($value, array('left', 'center', 'right'), true) ? $value : 'left';
}






function am_cmuk_elementor_stretch_header_bg() {
    $title_alignment = get_theme_mod('al_cmuk_site_title_alignment', 'left');
    $menu_alignment = get_theme_mod('al_cmuk_menu_alignment', 'right');

    $title_justify = function_exists('al_cmuk_alignment_to_justify') ? al_cmuk_alignment_to_justify($title_alignment, 'left') : 'flex-start';
    $menu_justify = function_exists('al_cmuk_alignment_to_justify') ? al_cmuk_alignment_to_justify($menu_alignment, 'right') : 'flex-end';

    $css = ':root{--al-cmuk-site-title-justify:' . esc_attr($title_justify) . ';--al-cmuk-menu-justify:' . esc_attr($menu_justify) . ';}'
    . '@media(min-width:1025px){'
    . '.cmuk-site-header,.cmuk-gov-header,header.cmuk-site-header,header.cmuk-gov-header,body>header{width:100vw!important;max-width:100vw!important;min-width:100vw!important;position:relative!important;left:50%!important;right:50%!important;margin-left:-50vw!important;margin-right:-50vw!important;box-sizing:border-box!important;overflow:visible!important;}'
    . '.cmuk-site-header:before,.cmuk-gov-header:before,header.cmuk-site-header:before,header.cmuk-gov-header:before,body>header:before{content:""!important;position:absolute!important;top:0!important;bottom:0!important;left:0!important;right:0!important;width:100%!important;height:100%!important;background:var(--cmuk-header-colour,#1d70b8)!important;z-index:-1!important;}'
    . '.cmuk-header-inner,.cmuk-gov-header__inner,header .cmuk-header-inner,header .site-header-inner{width:100vw!important;max-width:100vw!important;min-width:0!important;margin:0!important;padding-left:10px!important;padding-right:10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:0!important;position:relative!important;z-index:1!important;}'
    . '.cmuk-site-title,.cmuk-gov-header__brand,.site-title,header .site-title{flex:1 1 50%!important;width:50%!important;max-width:50%!important;min-width:0!important;margin:0!important;padding:0 10px 0 0!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($title_justify) . '!important;white-space:nowrap!important;}'
    . '.cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{flex:1 1 50%!important;width:50%!important;max-width:50%!important;min-width:0!important;margin:0!important;padding:0 0 0 10px!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu_justify) . '!important;}'
    . '.cmuk-menu,.menu,.main-navigation ul,header nav ul{width:auto!important;max-width:100%!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:' . esc_attr($menu_justify) . '!important;gap:0!important;}'
    . '}';

    wp_register_style('am-cmuk-elementor-stretch-header-bg', false, array(), '19.0.33');
    wp_enqueue_style('am-cmuk-elementor-stretch-header-bg');
    wp_add_inline_style('am-cmuk-elementor-stretch-header-bg', $css);
}
add_action('wp_enqueue_scripts', 'am_cmuk_elementor_stretch_header_bg', 10000);


/**
 * AN revision: hard-coded Elementor JSON style header.
 * No JSON import on runtime. Uses existing CMUK accordion menu.
 */
function an_cmuk_force_menu_depth($args) {
    if (is_array($args)) {
        $args['depth'] = 4;
        if (empty($args['fallback_cb'])) {
            $args['fallback_cb'] = false;
        }
    }
    return $args;
}
add_filter('wp_nav_menu_args', 'an_cmuk_force_menu_depth', 999);

function an_cmuk_json_header_assets() {
    // Intentionally empty: CSS is in style.css, existing accordion scripts from prior revisions remain active.
}
add_action('wp_enqueue_scripts', 'an_cmuk_json_header_assets', 1);


/**
 * AO revision: site title left edge alignment like menu edge alignment.
 */
function ao_cmuk_title_left_edge_fix() {
    $css = '
    :root{--cmuk-json-header-edge:10px;}
    .cmuk-json-header,.cmuk-json-header__section{width:100vw!important;max-width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important;}
    .cmuk-json-header__container{width:100%!important;max-width:100%!important;margin:0!important;padding-left:var(--cmuk-json-header-edge,10px)!important;padding-right:var(--cmuk-json-header-edge,10px)!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:0!important;}
    .cmuk-json-header__column--title{flex:1 1 50%!important;width:50%!important;max-width:50%!important;display:flex!important;align-items:center!important;justify-content:flex-start!important;margin:0!important;padding-left:0!important;padding-right:10px!important;box-sizing:border-box!important;}
    .cmuk-json-header__column--menu{flex:1 1 50%!important;width:50%!important;max-width:50%!important;display:flex!important;align-items:center!important;justify-content:flex-end!important;margin:0!important;padding-left:10px!important;padding-right:0!important;box-sizing:border-box!important;}
    .cmuk-json-header__title,.cmuk-json-header__title:link,.cmuk-json-header__title:visited,.cmuk-json-header__title:hover,.cmuk-json-header__title:focus,.cmuk-site-title,.site-title{width:auto!important;max-width:100%!important;margin:0!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:flex-start!important;text-align:left!important;color:#ffffff!important;text-decoration:none!important;font-size:16px!important;line-height:1.25!important;font-weight:700!important;min-height:64px!important;background:transparent!important;border:0!important;box-shadow:none!important;white-space:nowrap!important;}
    .cmuk-json-header .cmuk-menu>li>a,.cmuk-json-header .cmuk-menu a,.cmuk-json-header .cmuk-menu-toggle{font-size:16px!important;line-height:1.25!important;}
    @media(min-width:1025px){.cmuk-json-header .cmuk-primary-navigation{width:auto!important;max-width:100%!important;display:flex!important;align-items:center!important;justify-content:flex-end!important;}.cmuk-json-header .cmuk-menu{display:flex!important;align-items:center!important;justify-content:flex-end!important;width:auto!important;max-width:100%!important;margin:0!important;padding:0!important;gap:0!important;}}
    @media(max-width:1024px){.cmuk-json-header__container{min-height:64px!important;}.cmuk-json-header__title,.cmuk-json-header .cmuk-menu-toggle{min-height:64px!important;font-size:16px!important;}}';

    wp_register_style('ao-cmuk-title-left-edge-fix', false, array(), '19.0.35');
    wp_enqueue_style('ao-cmuk-title-left-edge-fix');
    wp_add_inline_style('ao-cmuk-title-left-edge-fix', $css);
}
add_action('wp_enqueue_scripts', 'ao_cmuk_title_left_edge_fix', 11000);


/**
 * AP revision: mobile menu toggle fix.
 */
function ap_cmuk_mobile_menu_toggle_script() {
    $script = "
    document.addEventListener('DOMContentLoaded', function () {

        var buttons = document.querySelectorAll('.cmuk-menu-toggle');

        buttons.forEach(function(button){

            var targetId = button.getAttribute('aria-controls');
            if(!targetId){
                return;
            }

            var nav = document.getElementById(targetId);
            if(!nav){
                return;
            }

            button.addEventListener('click', function(e){
                e.preventDefault();

                var isOpen = nav.classList.contains('is-open');

                if(isOpen){
                    nav.classList.remove('is-open');
                    button.classList.remove('is-open');
                    button.setAttribute('aria-expanded', 'false');
                } else {
                    nav.classList.add('is-open');
                    button.classList.add('is-open');
                    button.setAttribute('aria-expanded', 'true');
                }
            });

        });

    });
    ";

    wp_register_script('ap-cmuk-mobile-menu-toggle', '', array(), '19.0.36', true);
    wp_enqueue_script('ap-cmuk-mobile-menu-toggle');
    wp_add_inline_script('ap-cmuk-mobile-menu-toggle', $script);
}
add_action('wp_enqueue_scripts', 'ap_cmuk_mobile_menu_toggle_script', 12000);


function aq_cmuk_header_16_no_mobile_dividers() {
    $css = '
    .cmuk-json-header,.cmuk-json-header *,.cmuk-site-header,.cmuk-site-header *,.cmuk-gov-header,.cmuk-gov-header *,header .cmuk-header-inner,header .cmuk-header-inner *,header .site-header-inner,header .site-header-inner *{font-size:16px!important;line-height:1.25!important;}
    .cmuk-json-header__title,.cmuk-site-title,.site-title,.cmuk-menu-toggle,.cmuk-menu-toggle *,.cmuk-menu a,.menu a,header nav ul a{font-size:16px!important;line-height:1.25!important;}
    @media(max-width:1024px){
      .cmuk-json-header .cmuk-menu,.cmuk-json-header .cmuk-menu ul,.cmuk-json-header .cmuk-menu li,.cmuk-json-header .cmuk-menu a,.cmuk-menu,.cmuk-menu ul,.cmuk-menu li,.cmuk-menu a,.menu,.menu ul,.menu li,.menu a,header nav,header nav ul,header nav ul li,header nav ul li a{border:0!important;border-top:0!important;border-bottom:0!important;border-left:0!important;border-right:0!important;box-shadow:none!important;outline:0!important;background-image:none!important;}
      .cmuk-json-header .cmuk-menu li:hover,.cmuk-json-header .cmuk-menu li:focus,.cmuk-json-header .cmuk-menu li:focus-within,.cmuk-json-header .cmuk-menu li:active,.cmuk-json-header .cmuk-menu li.current-menu-item,.cmuk-json-header .cmuk-menu li.current_page_item,.cmuk-menu li:hover,.cmuk-menu li:focus,.cmuk-menu li:focus-within,.cmuk-menu li:active,.cmuk-menu li.current-menu-item,.cmuk-menu li.current_page_item,.menu li:hover,.menu li:focus,.menu li:focus-within,.menu li:active,.menu li.current-menu-item,.menu li.current_page_item,header nav ul li:hover,header nav ul li:focus,header nav ul li:focus-within,header nav ul li:active,header nav ul li.current-menu-item,header nav ul li.current_page_item{border:0!important;border-top:0!important;border-bottom:0!important;border-left:0!important;border-right:0!important;box-shadow:none!important;outline:0!important;background-image:none!important;}
      .cmuk-json-header .cmuk-menu li:before,.cmuk-json-header .cmuk-menu li:after,.cmuk-json-header .cmuk-menu a:before,.cmuk-json-header .cmuk-menu a:after,.cmuk-menu li:before,.cmuk-menu li:after,.cmuk-menu a:before,.cmuk-menu a:after,.menu li:before,.menu li:after,.menu a:before,.menu a:after,header nav ul li:before,header nav ul li:after,header nav ul a:before,header nav ul a:after{content:none!important;display:none!important;visibility:hidden!important;opacity:0!important;border:0!important;box-shadow:none!important;background:none!important;}
      .cmuk-menu-toggle,.cmuk-gov-header__toggle,header button[aria-controls]{border:0!important;border-left:0!important;box-shadow:none!important;gap:10px!important;}
    }';
    wp_register_style('aq-cmuk-header-16-no-mobile-dividers', false, array(), '19.0.37');
    wp_enqueue_style('aq-cmuk-header-16-no-mobile-dividers');
    wp_add_inline_style('aq-cmuk-header-16-no-mobile-dividers', $css);
}
add_action('wp_enqueue_scripts', 'aq_cmuk_header_16_no_mobile_dividers', 13000);








/* AW revision - hard code site title to 20px */
function aw_cmuk_site_title_hardcoded_20px() {

    $css = '
    .cmuk-json-header .cmuk-json-header__title,
    .cmuk-json-header .cmuk-json-header__title:link,
    .cmuk-json-header .cmuk-json-header__title:visited,
    .cmuk-json-header .cmuk-json-header__title:hover,
    .cmuk-json-header .cmuk-json-header__title:focus,
    .cmuk-json-header .cmuk-site-title,
    .cmuk-json-header .cmuk-site-title a,
    .cmuk-json-header .site-title,
    .cmuk-json-header .site-title a,
    header .cmuk-json-header__title,
    header .cmuk-site-title,
    header .cmuk-site-title a,
    header .site-title,
    header .site-title a{
        font-size:20px!important;
        line-height:1.1!important;
    }';

    echo '<style id="aw-cmuk-site-title-hardcoded-20px">' . $css . '</style>';
}
add_action('wp_head', 'aw_cmuk_site_title_hardcoded_20px', 999999);


/* AX revision - hard coded footer center alignment */
function ax_cmuk_footer_center_alignment() {

    $css = '
    footer,
    .site-footer,
    .cmuk-site-footer,
    .cmuk-footer,
    footer *,
    .site-footer *,
    .cmuk-site-footer *,
    .cmuk-footer *{
        text-align:center!important;
        justify-content:center!important;
        align-items:center!important;
    }';

    echo '<style id="ax-cmuk-footer-center-alignment">' . $css . '</style>';
}
add_action('wp_head', 'ax_cmuk_footer_center_alignment', 999999);

function ay_cmuk_mobile_menu_align_like_title() {
    $css = '
    @media(max-width:1024px){
        .cmuk-json-header .cmuk-primary-navigation,.cmuk-primary-navigation,.cmuk-gov-nav,.main-navigation,header nav{padding-left:22px!important;padding-right:22px!important;box-sizing:border-box!important;text-align:left!important;}
        .cmuk-json-header .cmuk-menu,.cmuk-json-header .cmuk-menu ul,.cmuk-menu,.cmuk-menu ul,.menu,.menu ul,header nav ul,header nav ul ul{text-align:left!important;}
        .cmuk-json-header .cmuk-menu li>a,.cmuk-json-header .cmuk-menu>li>a,.cmuk-json-header .cmuk-menu .sub-menu li>a,.cmuk-menu li>a,.cmuk-menu>li>a,.cmuk-menu .sub-menu li>a,.menu li>a,.menu>li>a,.menu .sub-menu li>a,header nav ul li>a,header nav ul>li>a,header nav .sub-menu li>a{justify-content:flex-start!important;text-align:left!important;padding-left:0!important;box-sizing:border-box!important;}
        .cmuk-json-header .menu-item-has-children>a:after,.cmuk-menu .menu-item-has-children>a:after,.menu .menu-item-has-children>a:after,header nav .menu-item-has-children>a:after{margin-left:auto!important;}
    }';
    wp_register_style('ay-cmuk-mobile-menu-align-like-title', false, array(), '19.0.42');
    wp_enqueue_style('ay-cmuk-mobile-menu-align-like-title');
    wp_add_inline_style('ay-cmuk-mobile-menu-align-like-title', $css);
}
add_action('wp_enqueue_scripts', 'ay_cmuk_mobile_menu_align_like_title', 999999);


/**
 * AZ revision - keep mobile accordion icons at the far right of each row.
 */
function az_cmuk_mobile_icons_end_of_row() {
    $css = '
    @media(max-width:1024px){
        .cmuk-json-header .cmuk-menu li>a,
        .cmuk-json-header .cmuk-menu>li>a,
        .cmuk-json-header .cmuk-menu .sub-menu li>a,
        .cmuk-menu li>a,
        .cmuk-menu>li>a,
        .cmuk-menu .sub-menu li>a,
        .menu li>a,
        .menu>li>a,
        .menu .sub-menu li>a,
        header nav ul li>a,
        header nav ul>li>a,
        header nav .sub-menu li>a{
            width:100%!important;
            max-width:100%!important;
            display:flex!important;
            align-items:center!important;
            justify-content:flex-start!important;
            text-align:left!important;
            box-sizing:border-box!important;
        }

        .cmuk-json-header .menu-item-has-children>a:after,
        .cmuk-menu .menu-item-has-children>a:after,
        .menu .menu-item-has-children>a:after,
        header nav .menu-item-has-children>a:after{
            margin-left:auto!important;
            margin-right:0!important;
            flex:0 0 auto!important;
            align-self:center!important;
        }

        .cmuk-json-header .cmuk-submenu-toggle,
        .cmuk-json-header .submenu-toggle,
        .cmuk-json-header .dropdown-toggle,
        .cmuk-json-header .cmuk-accordion-icon,
        .cmuk-menu .cmuk-submenu-toggle,
        .cmuk-menu .submenu-toggle,
        .cmuk-menu .dropdown-toggle,
        .cmuk-menu .cmuk-accordion-icon,
        .menu .cmuk-submenu-toggle,
        .menu .submenu-toggle,
        .menu .dropdown-toggle,
        .menu .cmuk-accordion-icon,
        header nav .cmuk-submenu-toggle,
        header nav .submenu-toggle,
        header nav .dropdown-toggle,
        header nav .cmuk-accordion-icon{
            margin-left:auto!important;
            margin-right:0!important;
            flex:0 0 auto!important;
            align-self:center!important;
            float:none!important;
            position:static!important;
        }
    }';

    wp_register_style('az-cmuk-mobile-icons-end-of-row', false, array(), '19.0.43');
    wp_enqueue_style('az-cmuk-mobile-icons-end-of-row');
    wp_add_inline_style('az-cmuk-mobile-icons-end-of-row', $css);
}
add_action('wp_enqueue_scripts', 'az_cmuk_mobile_icons_end_of_row', 999999);


/**
 * BA revision - footer site title + made with love text.
 */
function ba_cmuk_footer_styles() {

    $footer_bg   = get_theme_mod('cmuk_footer_background_colour', '#005ea5');
    $footer_text = get_theme_mod('cmuk_footer_text_colour', '#ffffff');

    $css = "
    .cmuk-footer{
        background: {$footer_bg};
        color: {$footer_text};
        padding:20px 15px;
        text-align:center;
        width:100%;
        box-sizing:border-box;
    }

    .cmuk-footer-inner{
        width:100%;
        max-width:100%;
        margin:0 auto;
    }

    .cmuk-footer-text{
        margin:0;
        font-size:16px;
        line-height:1.5;
        color: {$footer_text};
    }

    .cmuk-footer-text a{
        color: {$footer_text};
        text-decoration:none;
        font-weight:600;
    }

    .cmuk-footer-text a:hover,
    .cmuk-footer-text a:focus{
        color: {$footer_text};
        text-decoration:underline;
    }

    .cmuk-footer-divider{
        opacity:0.9;
    }";

    wp_register_style('ba-cmuk-footer-style', false, array(), '19.0.44');
    wp_enqueue_style('ba-cmuk-footer-style');
    wp_add_inline_style('ba-cmuk-footer-style', $css);
}
add_action('wp_enqueue_scripts', 'ba_cmuk_footer_styles', 999999);


/* BB revision - use same text colour behaviour as AZ header */
function bb_force_footer_text_colour_like_az() {

    $header_text = get_theme_mod('cmuk_header_text_colour', '#ffffff');

    $css = "
    .cmuk-footer,
    .cmuk-footer p,
    .cmuk-footer span,
    .cmuk-footer a{
        color: {$header_text} !important;
    }

    .cmuk-footer a:hover,
    .cmuk-footer a:focus{
        color: {$header_text} !important;
        opacity:0.9;
    }";

    wp_register_style('bb-footer-text-like-az', false, array(), '19.0.45');
    wp_enqueue_style('bb-footer-text-like-az');
    wp_add_inline_style('bb-footer-text-like-az', $css);
}
add_action('wp_enqueue_scripts', 'bb_force_footer_text_colour_like_az', 1000000);


/* BC revision - default footer text colour black */
function bc_default_footer_text_black($mods) {

    if (empty(get_theme_mod('cmuk_footer_text_colour'))) {
        set_theme_mod('cmuk_footer_text_colour', '#000000');
    }

    if (empty(get_theme_mod('cmuk_header_text_colour'))) {
        set_theme_mod('cmuk_header_text_colour', '#000000');
    }

    return $mods;
}
add_action('after_setup_theme', 'bc_default_footer_text_black');

/* BF revision - hide remaining CMUK alignment settings */
function bf_hide_remaining_cmuk_alignment_settings() {
    ?>
    <style>
    #customize-control-cmuk_footer_alignment,
    #customize-control-cmuk_site_title_alignment,
    #customize-control-cmuk_menu_bar_alignment,
    #customize-control-cmuk_menu_alignment,
    #customize-control-cmuk_site_title_position,
    #customize-control-cmuk_menu_position,
    [id*="site_title_alignment"],
    [id*="menu_alignment"],
    [id*="footer_alignment"]{
        display:none !important;
    }
    </style>
    <?php
}
add_action('customize_controls_print_styles', 'bf_hide_remaining_cmuk_alignment_settings', 999999);
