<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="cmuk-json-header cmuk-site-header" role="banner">
  <div class="cmuk-json-header__section">
    <div class="cmuk-json-header__container">
      <div class="cmuk-json-header__column cmuk-json-header__column--title">
        <a class="cmuk-json-header__title cmuk-site-title" href="<?php echo esc_url(home_url('/')); ?>">
          <?php bloginfo('name'); ?>
        </a>
      </div>

      <div class="cmuk-json-header__column cmuk-json-header__column--menu">
        <button class="cmuk-menu-toggle" type="button" aria-controls="cmuk-primary-menu-wrap" aria-expanded="false">
          <span class="cmuk-menu-toggle__icon" aria-hidden="true">▾</span><span class="cmuk-menu-toggle__text">Menu</span>
        </button>

        <nav id="cmuk-primary-menu-wrap" class="cmuk-primary-navigation cmuk-json-header__nav" aria-label="Primary menu">
          <?php
          wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_id'        => 'cmuk-primary-menu',
            'menu_class'     => 'cmuk-menu',
            'container'      => false,
            'fallback_cb'    => false,
            'depth'          => 4,
          ));
          ?>
        </nav>
      </div>
    </div>
  </div>
</header>

<main id="content" class="cmuk-site-main">
