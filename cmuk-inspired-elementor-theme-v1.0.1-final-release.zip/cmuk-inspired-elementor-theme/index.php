<?php get_header(); ?>

<main id="main-content" class="site-main">
<?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>
    <article <?php post_class(); ?>>
      <h1><?php the_title(); ?></h1>
      <div class="entry-content">
        <?php the_content(); ?>
      </div>
    </article>
  <?php endwhile; ?>
<?php else : ?>
  <h1><?php esc_html_e('Page not found', 'cmuk-inspired-elementor-theme'); ?></h1>
  <p><?php esc_html_e('No content was found.', 'cmuk-inspired-elementor-theme'); ?></p>
<?php endif; ?>
</main>

<?php get_footer(); ?>
