<?php get_header(); ?>

<main id="main-content" class="site-main">
<?php while (have_posts()) : the_post(); ?>
  <article <?php post_class(); ?>>
    <?php if (!get_post_meta(get_the_ID(), '_elementor_edit_mode', true)) : ?>
      <h1><?php the_title(); ?></h1>
    <?php endif; ?>
    <div class="entry-content">
      <?php the_content(); ?>
    </div>
  </article>
<?php endwhile; ?>
</main>

<?php get_footer(); ?>
