CMUK Inspired Elementor Theme v7

Changes in v5:
- Menu button now uses a CMUK-style small triangle icon instead of text symbols.
- Header links/buttons have no underline anywhere.
- Menu dropdown still works on mobile.
- Bullet/dot before menu items remains removed.
- Theme author is Connor Moizer only.
- Site text/logo links to homepage.
- Blue/black header option remains in Appearance > Customise > CMUK Header Options.

Install:
1. Upload this ZIP in WordPress > Appearance > Themes > Add New > Upload Theme.
2. Activate it.
3. Go to Appearance > Menus and assign a menu to Primary menu.
4. Go to Appearance > Customise > CMUK Header Options.

Elementor:
- Works with Elementor pages.
- Header colour can also be overridden with:
  [cmuk_header_style colour="blue"]
  [cmuk_header_style colour="black"]

Note:
This is CMUK-inspired only. It is not official, affiliated with, or endorsed by CMUK or HM Government.

- Header hover effects removed and replaced with transparent hover styling.

Changes in v7:
- Header blue/black background area made slightly taller.
- Site title/logo slightly increased for a stronger CMUK-style header presence.
- Mobile menu/search tap area increased.

Changes in v8:
- Fully removed visible hover/focus backgrounds from the header.
- Header hover/focus states are now fully transparent.

Changes in v9:
- Force removed ALL visible hover/focus/active header styling.

Changes in v10:
- Added Customizer range slider for Header hover transparency / opacity.
- Set the slider to 0 for completely transparent hover.
- Outputs inline CSS in the page head with very high priority to override stubborn hover styles.

Changes in v11:
- When hover opacity is set to 0, hover background now matches the exact header colour instead of using transparent rendering differences.
- Blue header hover matches CMUK blue exactly.
- Black header hover matches CMUK black exactly.

Changes in v12:
- Added Customizer option to turn the mobile menu button on/off.
- When disabled, the mobile dropdown navigation is hidden on mobile.
- Desktop menu remains available on desktop screens.

Changes in v13:
- Menu toggle now controls the whole header menu, not just mobile.
- Turning it off removes the desktop navigation, mobile Menu button, and mobile dropdown.
- Search icon can still be controlled separately.

Changes in v14:
- Rebuilt menu area to be about 90% close to the official CMUK Service Navigation component.
- Added separate CMUK-style service navigation bar below the main header.
- Service name links to homepage.
- Mobile Menu button collapses/expands the service navigation list.
- WordPress current menu item gets active/current styling.
- Added Customizer fields for service name and mobile menu button text.
- Keeps your site title/logo instead of the CMUK crown.

Changes in v15:
- Moved the CMUK-style service navigation into the blue/black header.
- Navigation now uses white text on the header background.
- Mobile dropdown still works.
- Active item indicator now uses white to match the header.

Changes in v16:
- Service navigation now matches the reference style more closely: blue header first, pale service box underneath.
- Service name is dynamic and can listen to the current CPT.
- On single CPT posts it shows the CPT singular label.
- On CPT archives it shows the CPT archive/plural label.
- Pages fall back to the Customizer service name/site name.

Changes in v17:
- Added a global Customizer toggle: Show service box globally.
- Added Elementor widget: CMUK Service Box Toggle.
- Drop the Elementor widget onto a page and switch "Show service box on this page" off to hide the service/CPT box on that page.
- Added shortcode fallback: [cmuk_service_box_toggle show="no"].

Changes in v18:
- Replaced shortcode-first workflow with real Customizer controls.
- Added CPT/post type checklist: tick which content types should show the service box.
- Service box now appears only on selected CPTs/post types.
- Global Show service box switch still exists.
- Shortcode remains only as fallback.

Changes in v19:
- Removed the theme-level service name/service box from the header output.
- Restored the original blue header menu/dropdown behaviour.
- Service name should now be handled by the Elementor component widget instead of the theme.
