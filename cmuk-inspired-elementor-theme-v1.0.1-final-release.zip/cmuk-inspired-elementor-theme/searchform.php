<?php
/**
 * Search has been intentionally disabled in this theme revision.
 * K revision: no search form output.
 */
if (!defined('ABSPATH')) {
    exit;
}
return;
